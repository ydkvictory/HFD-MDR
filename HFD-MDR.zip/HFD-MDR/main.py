#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Run the three HFD-MDR experiments with seed=0 and 80 epochs.

python main.py          ordinary 80:20 pair-level experiment (default)
python main.py cv       five-fold cross-validation
python main.py weights  feature-weight analysis and heatmaps
"""

import argparse
from pathlib import Path
import subprocess
import sys


PROJECT_DIR = Path(__file__).resolve().parent
EXPERIMENTS = {
    "split": "train_split.py",
    "cv": "train_cv.py",
    "weights": "analyze_weights.py",
}


def build_command(experiment="split", split_only=False):
    """Use the current Python environment and absolute project paths."""
    data_dir = PROJECT_DIR / "data"
    command = [
        sys.executable, "-u", str(PROJECT_DIR / "code" / EXPERIMENTS[experiment]),
        "--pos_sample", str(data_dir / "positive.edgelist"),
        "--neg_sample", str(data_dir / "negative.edgelist"),
        "--mirna_file", str(data_dir / "mirnas.xlsx"),
        "--drug_file", str(data_dir / "drugs.xlsx"),
        "--seed", "0", "--epochs", "80", "--batch", "32", "--workers", "0",
        "--lr", "5e-4", "--weight_decay", "5e-4", "--dropout", "0.5",
        "--entropy_reg_lambda", "2e-3", "--fusion_temperature", "1.5",
        "--strict_final3",
        "--outdir", str(PROJECT_DIR / "results" / experiment),
    ]
    if experiment == "split":
        command.extend(["--test_ratio", "0.2"])
        if split_only:
            command.append("--split_only")
    return command


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("experiment", nargs="?", default="split",
                        choices=tuple(EXPERIMENTS),
                        help="Default: ordinary 80:20 experiment.")
    parser.add_argument("--split_only", action="store_true",
                        help="Only save/audit the ordinary split; do not train.")
    args = parser.parse_args(argv)
    if args.split_only and args.experiment != "split":
        parser.error("--split_only is available only for the ordinary split.")
    script = PROJECT_DIR / "code" / EXPERIMENTS[args.experiment]
    if not script.is_file():
        parser.error(f"Missing experiment script: {script}. Extract the complete package.")
    for name in ["positive.edgelist", "negative.edgelist", "mirnas.xlsx", "drugs.xlsx",
                 "admet.csv", "targets.csv"]:
        path = PROJECT_DIR / "data" / name
        if not path.is_file():
            parser.error(f"Missing input data: {path}. Extract the complete package.")
    print(f"HFD-MDR: {args.experiment}; seed=0; epochs=80", flush=True)
    print(f"Results: {PROJECT_DIR / 'results' / args.experiment}", flush=True)
    result = subprocess.run(build_command(args.experiment, args.split_only), cwd=PROJECT_DIR)
    return result.returncode


if __name__ == "__main__":
    raise SystemExit(main())
