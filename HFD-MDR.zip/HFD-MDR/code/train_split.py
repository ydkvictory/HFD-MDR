import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from paths import DATA_DIR, RESULTS_DIR


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pos_sample", default=str(DATA_DIR / "positive.edgelist"))
    parser.add_argument("--neg_sample", default=str(DATA_DIR / "negative.edgelist"))
    parser.add_argument("--mirna_file", default=str(DATA_DIR / "mirnas.xlsx"))
    parser.add_argument("--drug_file", default=str(DATA_DIR / "drugs.xlsx"))
    parser.add_argument("--outdir", default=str(RESULTS_DIR / "split"))
    parser.add_argument("--test_ratio", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--workers", type=int, default=0)
    parser.add_argument("--batch", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--lr", type=float, default=5e-4)
    parser.add_argument("--weight_decay", type=float, default=5e-4)
    parser.add_argument("--dropout", type=float, default=0.5)
    parser.add_argument("--entropy_reg_lambda", type=float, default=2e-3)
    parser.add_argument("--fusion_temperature", type=float, default=1.5)
    parser.add_argument("--no_cuda", action="store_true")
    parser.add_argument("--strict_final3", action="store_true",
                        help="Require the supplied final MDR dataset dimensions.")
    parser.add_argument("--split_only", action="store_true",
                        help="Save and audit the exact split without importing model dependencies.")

    # Keep the existing train_cv.py/model.py parameter names and defaults.
    parser.add_argument("--drug_input_dim", type=int, default=69)
    parser.add_argument("--drug_hidden_dim", type=int, default=128)
    parser.add_argument("--drug_feature_dim", type=int, default=128)
    parser.add_argument("--mirna_feature_dim", type=int, default=128)
    parser.add_argument("--drug_desc_dim", type=int, default=64)
    parser.add_argument("--drug_fp_dim", type=int, default=256)
    parser.add_argument("--drug_admet_dim", type=int, default=21)
    parser.add_argument("--drug_target_raw_dim", type=int, default=523)
    parser.add_argument("--admet_token_dim", type=int, default=128)
    parser.add_argument("--admet_num_heads", type=int, default=4)
    parser.add_argument("--admet_num_layers", type=int, default=1)
    parser.add_argument("--target_concept_dim", type=int, default=128)
    parser.add_argument("--target_topk", type=int, default=12)
    parser.add_argument("--target_num_heads", type=int, default=4)
    parser.add_argument("--target_num_layers", type=int, default=1)

    args = parser.parse_args(argv)
    if not 0 < args.test_ratio < 1:
        parser.error("--test_ratio must be between 0 and 1.")
    if args.epochs < 1 or args.batch < 1 or args.workers < 0:
        parser.error("epochs/batch must be positive and workers nonnegative.")
    if not 0 <= args.seed < 2**32:
        parser.error("--seed must be between 0 and 2**32 - 1.")
    return args


def read_pairs(path):
    pairs = np.loadtxt(path, dtype=np.int64, ndmin=2)
    if pairs.shape[1] != 2 or len(pairs) == 0:
        raise ValueError(f"{path} must contain nonempty miRNA_idx/drug_idx pairs.")
    if np.any(pairs < 0):
        raise ValueError(f"{path} contains a negative entity index.")
    if len(np.unique(pairs, axis=0)) != len(pairs):
        raise ValueError(f"{path} contains duplicate pairs.")
    return pairs


def build_pair_split(positive, negative_pool, seed=0, test_ratio=0.2):
    """Match the original NumPy RandomState shuffle and per-class slicing."""
    positive = np.asarray(positive, dtype=np.int64).copy()
    negative_pool = np.asarray(negative_pool, dtype=np.int64).copy()
    n_positive = len(positive)
    if len(negative_pool) < n_positive:
        raise ValueError("The negative pool is smaller than the positive set.")
    n_test_per_class = int(test_ratio * n_positive)
    if not 0 < n_test_per_class < n_positive:
        raise ValueError("The ratio/data size must leave both train and test pairs.")

    rng = np.random.RandomState(seed)
    rng.shuffle(positive)
    rng.shuffle(negative_pool)
    negative = negative_pool[:n_positive]
    positive = np.column_stack((positive, np.ones(n_positive, dtype=np.int64)))
    negative = np.column_stack((negative, np.zeros(n_positive, dtype=np.int64)))
    train = np.vstack((positive[:-n_test_per_class], negative[:-n_test_per_class]))
    test = np.vstack((positive[-n_test_per_class:], negative[-n_test_per_class:]))

    train_pairs = set(map(tuple, train[:, :2]))
    test_pairs = set(map(tuple, test[:, :2]))
    positive_pairs = set(map(tuple, positive[:, :2]))
    negative_pairs = set(map(tuple, negative[:, :2]))
    if train_pairs & test_pairs or positive_pairs & negative_pairs:
        raise ValueError("Train/test overlap or conflicting positive/negative pairs.")

    audit = {
        "protocol": "ordinary miRNA-drug pair-level holdout",
        "sampling": "legacy NumPy RandomState; shuffled 1:1 positive/negative pairs",
        "seed": int(seed),
        "requested_test_ratio": float(test_ratio),
        "actual_test_ratio": float(len(test) / (len(train) + len(test))),
        "train_pairs": int(len(train)),
        "test_pairs": int(len(test)),
        "train_positive": int((train[:, 2] == 1).sum()),
        "train_negative": int((train[:, 2] == 0).sum()),
        "test_positive": int((test[:, 2] == 1).sum()),
        "test_negative": int((test[:, 2] == 0).sum()),
        "train_test_pair_overlap": 0,
        "positive_negative_pair_overlap": 0,
        "shared_drugs": int(len(set(train[:, 1]) & set(test[:, 1]))),
        "shared_mirnas": int(len(set(train[:, 0]) & set(test[:, 0]))),
        "drug_cold_start": False,
    }
    return train, test, audit


def save_test_outputs(predictions, metric, outdir):
    """Export all test predictions, six metrics and ROC/PR coordinates/figures."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve, precision_recall_curve

    predictions.to_csv(outdir / "predictions.csv", index=False, encoding="utf-8-sig")
    row = {"auc": metric["auc"], "aupr": metric["aupr"],
           "accuracy": metric["acc"], "precision": metric["precision"],
           "recall": metric["recall"], "f1": metric["f1"],
           "test_loss": metric["loss"]}
    pd.DataFrame([row]).to_csv(outdir / "metrics.csv", index=False, encoding="utf-8-sig")
    y = predictions["true_label"].to_numpy(dtype=int)
    p = predictions["pred_prob"].to_numpy(dtype=float)
    fpr, tpr, roc_threshold = roc_curve(y, p)
    precision, recall, pr_threshold = precision_recall_curve(y, p)
    pr_threshold_col = np.full(len(precision), np.nan)
    pr_threshold_col[:len(pr_threshold)] = pr_threshold
    pd.DataFrame({"fpr": fpr, "tpr": tpr, "threshold": roc_threshold}).to_csv(
        outdir / "roc.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame({"recall": recall, "precision": precision,
                  "threshold": pr_threshold_col}).to_csv(
        outdir / "pr.csv", index=False, encoding="utf-8-sig")

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(fpr, tpr, label=f"HFD-MDR (AUC = {metric['auc']:.4f})")
    ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1, color="gray")
    ax.set(xlim=(0, 1), ylim=(0, 1), xlabel="False Positive Rate",
           ylabel="True Positive Rate", title="ROC curve (80:20 pair split)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(outdir / "roc.png", dpi=600, bbox_inches="tight")
    fig.savefig(outdir / "roc.pdf", bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 6))
    ax.plot(recall, precision, label=f"HFD-MDR (AUPR/AP = {metric['aupr']:.4f})")
    ax.set(xlim=(0, 1), ylim=(0, 1), xlabel="Recall", ylabel="Precision",
           title="Precision-Recall curve (80:20 pair split)")
    ax.legend(loc="lower left")
    fig.tight_layout()
    fig.savefig(outdir / "pr.png", dpi=600, bbox_inches="tight")
    fig.savefig(outdir / "pr.pdf", bbox_inches="tight")
    plt.close(fig)
    return row


def run_training(args, train, test, outdir):
    # Keep --help/--split_only usable without pretrained-model dependencies.
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from data import load_drug_data, load_mirna_data
    from model import DrugMiRNAInteractionModel
    from train_cv import set_seed, make_loader, forward_batch, calculate_metrics, evaluate_final

    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() and not args.no_cuda else "cpu")
    drug_features, _ = load_drug_data(args.drug_file)
    mirna_features, _ = load_mirna_data(args.mirna_file)
    train_loader = make_loader(train, drug_features, mirna_features, args,
                               shuffle=True, seed=args.seed)
    test_loader = make_loader(test, drug_features, mirna_features, args,
                              shuffle=False, seed=args.seed)
    model = DrugMiRNAInteractionModel(args).to(device)
    optimizer = optim.Adam(filter(lambda p: p.requires_grad, model.parameters()),
                           lr=args.lr, weight_decay=args.weight_decay)
    criterion = nn.BCELoss()
    history = []
    print(f"Device: {device}; train={len(train)}, test={len(test)}, epochs={args.epochs}")

    for epoch in range(1, args.epochs + 1):
        model.train()
        labels_all, probabilities_all = [], []
        bce_sum, total_n = 0.0, 0
        for batch in train_loader:
            outputs, labels, entropy_reg = forward_batch(model, batch, device)
            bce = criterion(outputs, labels)
            loss = bce - args.entropy_reg_lambda * entropy_reg
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            bs = labels.shape[0]
            bce_sum += float(bce.item()) * bs
            total_n += bs
            labels_all.extend(labels.detach().cpu().numpy().tolist())
            probabilities_all.extend(outputs.detach().cpu().numpy().tolist())
        train_metric = calculate_metrics(labels_all, probabilities_all)
        history.append({"epoch": epoch, "train_loss": bce_sum / max(total_n, 1),
                        **{"train_" + k: v for k, v in train_metric.items()}})
        print(f"Epoch {epoch:03d}/{args.epochs} | Train AUC={train_metric['auc']:.4f} "
              f"AUPR={train_metric['aupr']:.4f} ACC={train_metric['acc']:.4f}")

    # Fixed final epoch, with no test-based checkpoint or epoch selection.
    metric, predictions = evaluate_final(model, test_loader, test, device)
    pd.DataFrame(history).to_csv(outdir / "history.csv", index=False, encoding="utf-8-sig")
    return save_test_outputs(predictions, metric, outdir)


def main(argv=None):
    args = parse_args(argv)
    outdir = Path(args.outdir).expanduser().resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    positive = read_pairs(args.pos_sample)
    negative_pool = read_pairs(args.neg_sample)
    dataset = {"mirnas": len(pd.read_excel(args.mirna_file)),
               "drugs": len(pd.read_excel(args.drug_file)),
               "positives": len(positive), "negative_pool": len(negative_pool)}
    expected = {"mirnas": 1314, "drugs": 105, "positives": 5389, "negative_pool": 132581}
    if args.strict_final3 and dataset != expected:
        raise ValueError(f"Final dataset check failed: {dataset}; expected {expected}")
    for name, pairs in [("positive", positive), ("negative", negative_pool)]:
        if np.any(pairs[:, 0] >= dataset["mirnas"]) or np.any(pairs[:, 1] >= dataset["drugs"]):
            raise ValueError(f"{name} contains an entity index outside the supplied tables.")
    train, test, audit = build_pair_split(positive, negative_pool, args.seed, args.test_ratio)
    for name, pairs in [("train", train), ("test", test)]:
        pd.DataFrame(pairs, columns=["mirna_idx", "drug_idx", "label"]).to_csv(
            outdir / f"{name}.csv", index=False, encoding="utf-8-sig")
    summary = {"dataset": dataset, "split": audit, "settings": vars(args),
               "status": "split_only" if args.split_only else "training_pending",
               "evaluation": {"epochs": args.epochs, "validation_used": False,
                              "early_stopping_used": False, "test_evaluations": 0,
                              "threshold": 0.5, "aupr_method": "average_precision_score",
                              "test_shuffle": False, "test_drop_last": False}}
    summary_path = outdir / "experiment.json"
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(audit, ensure_ascii=False, indent=2))
    if not args.split_only:
        metric = run_training(args, train, test, outdir)
        summary["status"] = "completed"
        summary["evaluation"]["test_evaluations"] = 1
        summary["metrics"] = metric
        summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
        print("Final test metrics:", metric)
    print("Results saved to:", outdir)


if __name__ == "__main__":
    main()
