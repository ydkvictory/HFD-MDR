import os
import json
import random
import argparse
from pathlib import Path
from paths import RESULTS_DIR

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    accuracy_score,
    roc_auc_score,
    average_precision_score,
    precision_score,
    recall_score,
    f1_score,
    roc_curve,
    precision_recall_curve,
)

from data import (
    Data_class,
    collate_fn,
    load_drug_data,
    load_mirna_data,
)
from model import DrugMiRNAInteractionModel
from analyze_weights import select_4weights, aggregate_drug_weights


# ============================================================
# 1. 参数
# ============================================================

def parse_args():
    p = argparse.ArgumentParser()

    p.add_argument("--pos_sample", required=True)
    p.add_argument("--neg_sample", required=True)
    p.add_argument("--mirna_file", required=True)
    p.add_argument("--drug_file", required=True)
    

    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--workers", type=int, default=0)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--epochs", type=int, default=80)
    p.add_argument("--lr", type=float, default=5e-4)
    p.add_argument("--weight_decay", type=float, default=5e-4)

    p.add_argument("--dropout", type=float, default=0.5)
    p.add_argument("--entropy_reg_lambda", type=float, default=2e-3)
    p.add_argument("--fusion_temperature", type=float, default=1.5)

    p.add_argument(
        "--outdir",
        default=str(RESULTS_DIR / "cv"),
    )

    p.add_argument(
        "--strict_final3",
        action="store_true",
        help="要求数据必须为 1314 miRNAs / 105 drugs / 5389 positives / 132581 negatives。",
    )

    p.add_argument(
        "--no_cuda",
        action="store_true",
        default=False,
    )

    # 当前工程模型参数
    p.add_argument("--drug_input_dim", type=int, default=69)
    p.add_argument("--drug_hidden_dim", type=int, default=128)
    p.add_argument("--drug_feature_dim", type=int, default=128)
    p.add_argument("--mirna_feature_dim", type=int, default=128)

    p.add_argument("--drug_desc_dim", type=int, default=64)
    p.add_argument("--drug_fp_dim", type=int, default=256)

    p.add_argument("--drug_admet_dim", type=int, default=21)
    p.add_argument("--drug_target_raw_dim", type=int, default=523)

    p.add_argument("--admet_token_dim", type=int, default=128)
    p.add_argument("--admet_num_heads", type=int, default=4)
    p.add_argument("--admet_num_layers", type=int, default=1)

    p.add_argument("--target_concept_dim", type=int, default=128)
    p.add_argument("--target_topk", type=int, default=12)
    p.add_argument("--target_num_heads", type=int, default=4)
    p.add_argument("--target_num_layers", type=int, default=1)

    return p.parse_args()


# ============================================================
# 2. 可复现性 / 数据工具
# ============================================================

def set_seed(seed):
    os.environ["PYTHONHASHSEED"] = str(seed)

    random.seed(seed)
    np.random.seed(seed)

    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def read_edges(path):
    arr = np.loadtxt(path, dtype=np.int64)

    if arr.ndim == 1:
        arr = arr.reshape(1, -1)

    if arr.shape[1] != 2:
        raise ValueError(
            f"{path} 必须为两列：miRNA_idx drug_idx"
        )

    return arr


def calculate_metrics(y_true, prob):
    y_true = np.asarray(y_true, dtype=np.int64)
    prob = np.asarray(prob, dtype=np.float64)

    pred = (prob >= 0.5).astype(np.int64)

    return {
        "acc": accuracy_score(y_true, pred),
        "auc": roc_auc_score(y_true, prob),
        "aupr": average_precision_score(y_true, prob),
        "precision": precision_score(
            y_true,
            pred,
            zero_division=0,
        ),
        "recall": recall_score(
            y_true,
            pred,
            zero_division=0,
        ),
        "f1": f1_score(
            y_true,
            pred,
            zero_division=0,
        ),
    }


def make_loader(
    data,
    drug_features,
    mirna_features,
    args,
    shuffle,
    seed,
):
    dataset = Data_class(
        data,
        drug_features=drug_features,
        mirna_features=mirna_features,
    )

    generator = torch.Generator()
    generator.manual_seed(seed)

    return DataLoader(
        dataset,
        batch_size=args.batch,
        shuffle=shuffle,
        num_workers=args.workers,
        collate_fn=collate_fn,
        drop_last=False,
        generator=generator if shuffle else None,
    )


def forward_batch(model, batch, device):
    outputs, _, entropy_reg = model(
        batch["drug_graphs"],
        batch["drug_smiles"],
        batch["drug_desc"].to(device),
        batch["drug_fp"].to(device),
        batch["drug_admet"].to(device),
        batch["drug_target_pathway"].to(device),
        batch["mirna_encoded"].to(device),
        batch["mirna_seqs"],
    )

    outputs = torch.nan_to_num(
        outputs,
        nan=0.5,
        posinf=1.0,
        neginf=0.0,
    )

    outputs = torch.clamp(
        outputs,
        min=1e-6,
        max=1.0 - 1e-6,
    )

    labels = batch["labels"].to(device)

    return outputs, labels, entropy_reg


def evaluate_final(
    model,
    loader,
    test_data,
    device,
):
    """
    DataLoader shuffle=False，因此输出顺序与 test_data 顺序一致。
    不依赖 batch 是否额外提供 mirna_indices / drug_indices。
    """
    model.eval()

    criterion = nn.BCELoss()

    all_y = []
    all_p = []

    total_loss = 0.0
    total_n = 0

    with torch.no_grad():
        for batch in loader:

            outputs, labels, _ = forward_batch(
                model,
                batch,
                device,
            )

            loss = criterion(
                outputs,
                labels,
            )

            bs = labels.shape[0]

            total_loss += float(loss.item()) * bs
            total_n += bs

            all_y.extend(
                labels.detach().cpu().numpy().tolist()
            )

            all_p.extend(
                outputs.detach().cpu().numpy().tolist()
            )

    y_true = np.asarray(
        all_y,
        dtype=np.int64,
    )

    prob = np.asarray(
        all_p,
        dtype=np.float64,
    )

    if len(prob) != len(test_data):
        raise RuntimeError(
            f"预测数量 {len(prob)} 与 test_data 数量 {len(test_data)} 不一致"
        )

    metric = calculate_metrics(
        y_true,
        prob,
    )

    metric["loss"] = (
        total_loss / max(total_n, 1)
    )

    pred_label = (
        prob >= 0.5
    ).astype(np.int64)

    pred_df = pd.DataFrame({
        "mirna_idx": test_data[:, 0].astype(int),
        "drug_idx": test_data[:, 1].astype(int),
        "true_label": y_true,
        "pred_prob": prob,
        "pred_label": pred_label,
    })

    return metric, pred_df


# ============================================================
# 3. 五折权重导出 / 汇总工具
# ============================================================

WEIGHT_COLUMNS_EFFECTIVE = [
    "SMILES", "Graph", "ADMET", "Target", "Chemical", "Mechanism"
]


def forward_batch_with_fusion(model, batch, device):
    """Forward pass that keeps fusion_info for post-training interpretation."""
    outputs, fusion_info, entropy_reg = model(
        batch["drug_graphs"],
        batch["drug_smiles"],
        batch["drug_desc"].to(device),
        batch["drug_fp"].to(device),
        batch["drug_admet"].to(device),
        batch["drug_target_pathway"].to(device),
        batch["mirna_encoded"].to(device),
        batch["mirna_seqs"],
    )

    outputs = torch.nan_to_num(
        outputs,
        nan=0.5,
        posinf=1.0,
        neginf=0.0,
    )
    outputs = torch.clamp(outputs, min=1e-6, max=1.0 - 1e-6)
    labels = batch["labels"].to(device)
    return outputs, labels, fusion_info, entropy_reg


def export_fold_weights(
    model,
    fold,
    probe_data,
    drug_features,
    mirna_features,
    args,
    device,
    outdir,
):
    """
    Freeze the trained fold model and extract fusion weights on ONE COMMON
    probe set shared by all five folds. No parameter update is performed here.

    Outputs per fold:
      fold_k_pair_weights.csv
      fold_k_drug_weights.csv
      fold_k_mean_weights.csv
    """
    probe_loader = make_loader(
        probe_data,
        drug_features,
        mirna_features,
        args,
        shuffle=False,
        seed=args.seed,
    )

    model.eval()
    rows = []
    selected_tensor_name = None

    with torch.no_grad():
        for batch in probe_loader:
            outputs, labels, fusion_info, _ = forward_batch_with_fusion(
                model,
                batch,
                device,
            )

            bs = labels.shape[0]
            best, _ = select_4weights(fusion_info, bs)
            selected_tensor_name = best["name"]
            w = best["tensor"].numpy()

            mirna_idx = (
                batch["mirna_indices"].detach().cpu().numpy().astype(int)
            )
            drug_idx = (
                batch["drug_indices"].detach().cpu().numpy().astype(int)
            )

            for i in range(bs):
                smiles = float(w[i, 0])
                graph = float(w[i, 1])
                admet = float(w[i, 2])
                target = float(w[i, 3])

                rows.append({
                    "fold": int(fold),
                    "mirna_idx": int(mirna_idx[i]),
                    "drug_idx": int(drug_idx[i]),
                    "label": int(labels[i].item()),
                    "pred_prob": float(outputs[i].item()),
                    "SMILES": smiles,
                    "Graph": graph,
                    "ADMET": admet,
                    "Target": target,
                    "Chemical": smiles + graph,
                    "Mechanism": admet + target,
                    "weight_sum": smiles + graph + admet + target,
                })

    pair_df = pd.DataFrame(rows)
    pair_path = outdir / f"fold{fold}_pair_weights.csv"
    pair_df.to_csv(pair_path, index=False, encoding="utf-8-sig")

    drug_weights = aggregate_drug_weights(pair_df, args.drug_file)
    drug_weights = drug_weights.sort_values("drug_idx").reset_index(drop=True)

    # Safety checks: same 105 drugs and normalized effective 4-modal weights.
    if args.strict_final3 and len(drug_weights) != 105:
        raise RuntimeError(
            f"Fold {fold}: expected 105 drugs in probe export, got {len(drug_weights)}"
        )

    max_sum_error = float(
        np.max(np.abs(drug_weights["weight_sum"].to_numpy(float) - 1.0))
    )
    if max_sum_error > 5e-2:
        raise RuntimeError(
            f"Fold {fold}: effective four-weight sum check failed; "
            f"max error={max_sum_error:.6f}"
        )

    drug_path = outdir / f"fold{fold}_drug_weights.csv"
    drug_weights.to_csv(drug_path, index=False, encoding="utf-8-sig")

    # --------------------------------------------------------
    # Two views of the learned weights
    # 1) Effective weights: 4 modalities after hierarchical scaling.
    # 2) Intra-layer shares: recover the two softmax proportions within
    #    Chemical and Mechanism, matching the method description/table.
    # --------------------------------------------------------
    eps = 1e-12
    chemical = drug_weights["Chemical"].to_numpy(float)
    mechanism = drug_weights["Mechanism"].to_numpy(float)

    smiles_intra = (
        drug_weights["SMILES"].to_numpy(float) / np.maximum(chemical, eps)
    )
    graph_intra = (
        drug_weights["Graph"].to_numpy(float) / np.maximum(chemical, eps)
    )
    admet_intra = (
        drug_weights["ADMET"].to_numpy(float) / np.maximum(mechanism, eps)
    )
    target_intra = (
        drug_weights["Target"].to_numpy(float) / np.maximum(mechanism, eps)
    )

    summary = {
        "fold": int(fold),
        "SMILES": float(np.mean(smiles_intra)),
        "Graph": float(np.mean(graph_intra)),
        "ADMET": float(np.mean(admet_intra)),
        "Target": float(np.mean(target_intra)),
        "Chemical": float(np.mean(chemical)),
        "Mechanism": float(np.mean(mechanism)),
        "Effective_SMILES": float(drug_weights["SMILES"].mean()),
        "Effective_Graph": float(drug_weights["Graph"].mean()),
        "Effective_ADMET": float(drug_weights["ADMET"].mean()),
        "Effective_Target": float(drug_weights["Target"].mean()),
        "selected_tensor": str(selected_tensor_name),
        "max_weight_sum_error": max_sum_error,
        "n_probe_pairs": int(len(pair_df)),
        "n_drugs": int(len(drug_weights)),
    }

    pd.DataFrame([summary]).to_csv(
        outdir / f"fold{fold}_mean_weights.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print(
        f"Fold {fold} WEIGHTS | "
        f"Chemical intra [SMILES={summary['SMILES']:.4f}, "
        f"Graph={summary['Graph']:.4f}] | "
        f"Mechanism intra [ADMET={summary['ADMET']:.4f}, "
        f"Target={summary['Target']:.4f}] | "
        f"Hierarchy [Chemical={summary['Chemical']:.4f}, "
        f"Mechanism={summary['Mechanism']:.4f}]"
    )

    return summary


def make_5fold_weight_tables(weight_summaries, outdir):
    """Create raw and paper-ready 5-fold learned-weight tables."""
    fold_df = pd.DataFrame(weight_summaries).sort_values("fold").reset_index(drop=True)
    fold_df.to_csv(
        outdir / "weight_means.csv",
        index=False,
        encoding="utf-8-sig",
    )

    feature_spec = [
        ("Chemical", "SMILES", "SMILES"),
        ("Chemical", "Graph", "Graph"),
        ("Mechanism", "ADMET", "ADMET"),
        ("Mechanism", "Target", "Target"),
        ("Hierarchical", "Chemical", "Chemical"),
        ("Hierarchical", "Mechanism", "Mechanism"),
    ]

    raw_rows = []
    paper_rows = []

    for level, feature, col in feature_spec:
        values = fold_df[col].to_numpy(dtype=float)
        mean = float(np.mean(values))
        sd = float(np.std(values, ddof=1))

        raw_row = {
            "Feature level": level,
            "Feature": feature,
        }
        paper_row = {
            "Feature level": level,
            "Feature": feature,
        }

        for i, value in enumerate(values, start=1):
            raw_row[f"Fold {i}"] = value
            paper_row[f"Fold {i}"] = f"{value:.4f}"

        raw_row["Mean"] = mean
        raw_row["SD"] = sd
        paper_row["Mean ± SD"] = f"{mean:.4f} ± {sd:.4f}"

        raw_rows.append(raw_row)
        paper_rows.append(paper_row)

    raw_table = pd.DataFrame(raw_rows)
    paper_table = pd.DataFrame(paper_rows)

    raw_table.to_csv(
        outdir / "layer_weights.csv",
        index=False,
        encoding="utf-8-sig",
    )
    paper_table.to_csv(
        outdir / "layer_weights_paper.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Also save the effective four-modality weights used in the heatmap.
    effective_cols = [
        "Effective_SMILES",
        "Effective_Graph",
        "Effective_ADMET",
        "Effective_Target",
    ]
    effective_rows = []
    for col in effective_cols:
        values = fold_df[col].to_numpy(dtype=float)
        effective_rows.append({
            "Feature": col.replace("Effective_", ""),
            **{f"Fold {i}": values[i-1] for i in range(1, 6)},
            "Mean": float(np.mean(values)),
            "SD": float(np.std(values, ddof=1)),
        })

    pd.DataFrame(effective_rows).to_csv(
        outdir / "modality_weights.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Plain-text table for quick copy/check.
    (outdir / "layer_weights.txt").write_text(
        paper_table.to_string(index=False),
        encoding="utf-8",
    )

    # LaTeX three-line-table body.
    latex_lines = [
        r"\begin{table*}[htbp]",
        r"\centering",
        r"\caption{Learned hierarchical drug-feature fusion weights across five folds.}",
        r"\begin{tabular}{llcccccc}",
        r"\toprule",
        r"Feature level & Feature & Fold 1 & Fold 2 & Fold 3 & Fold 4 & Fold 5 & Mean $\pm$ SD \\",
        r"\midrule",
    ]

    for row in paper_rows:
        latex_lines.append(
            f"{row['Feature level']} & {row['Feature']} & "
            f"{row['Fold 1']} & {row['Fold 2']} & {row['Fold 3']} & "
            f"{row['Fold 4']} & {row['Fold 5']} & {row['Mean ± SD']} \\\\" 
        )

    latex_lines += [
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{table*}",
    ]

    (outdir / "layer_weights.tex").write_text(
        "\n".join(latex_lines),
        encoding="utf-8",
    )

    print("\n5-FOLD HIERARCHICAL WEIGHT TABLE")
    print(paper_table.to_string(index=False))
    print(
        "\nSaved weight table:",
        outdir / "layer_weights_paper.csv",
    )

    return fold_df, raw_table, paper_table


# ============================================================
# 4. 单折：完整 80% Train，固定训练全部 epochs
# ============================================================

def train_one_fold(
    fold,
    train_data,
    test_data,
    probe_data,
    drug_features,
    mirna_features,
    args,
    device,
    outdir,
):
    fold_seed = args.seed + fold

    set_seed(fold_seed)

    train_loader = make_loader(
        train_data,
        drug_features,
        mirna_features,
        args,
        shuffle=True,
        seed=fold_seed,
    )

    test_loader = make_loader(
        test_data,
        drug_features,
        mirna_features,
        args,
        shuffle=False,
        seed=fold_seed,
    )

    model = DrugMiRNAInteractionModel(
        args
    ).to(device)

    optimizer = optim.Adam(
        filter(
            lambda p: p.requires_grad,
            model.parameters(),
        ),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    criterion = nn.BCELoss()

    history = []

    # --------------------------------------------------------
    # 无 early stopping
    # 无 validation
    # 每一折完整训练 args.epochs 轮
    # --------------------------------------------------------
    for epoch in range(
        1,
        args.epochs + 1,
    ):

        model.train()

        all_y = []
        all_p = []

        bce_sum = 0.0
        total_n = 0

        for batch in train_loader:

            outputs, labels, entropy_reg = forward_batch(
                model,
                batch,
                device,
            )

            bce = criterion(
                outputs,
                labels,
            )

            loss = (
                bce
                - args.entropy_reg_lambda
                * entropy_reg
            )

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            bs = labels.shape[0]

            bce_sum += (
                float(bce.item()) * bs
            )

            total_n += bs

            all_y.extend(
                labels.detach().cpu().numpy().tolist()
            )

            all_p.extend(
                outputs.detach().cpu().numpy().tolist()
            )

        train_metric = calculate_metrics(
            all_y,
            all_p,
        )

        train_loss = (
            bce_sum / max(total_n, 1)
        )

        history.append({
            "fold": fold,
            "epoch": epoch,
            "train_loss": train_loss,
            "train_acc": train_metric["acc"],
            "train_auc": train_metric["auc"],
            "train_aupr": train_metric["aupr"],
            "train_precision": train_metric["precision"],
            "train_recall": train_metric["recall"],
            "train_f1": train_metric["f1"],
        })

        print(
            f"Fold {fold}/5 | "
            f"Epoch {epoch:03d}/{args.epochs} | "
            f"Train AUC={train_metric['auc']:.4f} "
            f"AUPR={train_metric['aupr']:.4f} "
            f"ACC={train_metric['acc']:.4f}"
        )

    # 第 args.epochs 轮结束以后 Test 只评价一次
    test_metric, pred_df = evaluate_final(
        model,
        test_loader,
        test_data,
        device,
    )

    history_df = pd.DataFrame(
        history
    )

    history_df.to_csv(
        outdir
        / f"fold{fold}_history.csv",
        index=False,
        encoding="utf-8-sig",
    )

    pred_df.to_csv(
        outdir
        / f"fold{fold}_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # ROC points
    fpr, tpr, roc_thresholds = roc_curve(
        pred_df["true_label"].to_numpy(),
        pred_df["pred_prob"].to_numpy(),
    )

    roc_df = pd.DataFrame({
        "fold": fold,
        "fpr": fpr,
        "tpr": tpr,
        "threshold": roc_thresholds,
    })

    roc_df.to_csv(
        outdir
        / f"fold{fold}_roc.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # PR points
    precision, recall, pr_thresholds = precision_recall_curve(
        pred_df["true_label"].to_numpy(),
        pred_df["pred_prob"].to_numpy(),
    )

    threshold_col = np.full(
        len(precision),
        np.nan,
        dtype=float,
    )

    threshold_col[:len(pr_thresholds)] = pr_thresholds

    pr_df = pd.DataFrame({
        "fold": fold,
        "recall": recall,
        "precision": precision,
        "threshold": threshold_col,
    })

    pr_df.to_csv(
        outdir
        / f"fold{fold}_pr.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Export learned fusion weights using the same common probe set for all folds.
    weight_summary = export_fold_weights(
        model=model,
        fold=fold,
        probe_data=probe_data,
        drug_features=drug_features,
        mirna_features=mirna_features,
        args=args,
        device=device,
        outdir=outdir,
    )

    return {
        "fold": fold,
        "weight_summary": weight_summary,
        "epochs": args.epochs,
        "train_pairs": len(train_data),
        "test_pairs": len(test_data),

        "loss": test_metric["loss"],
        "auc": test_metric["auc"],
        "aupr": test_metric["aupr"],
        "accuracy": test_metric["acc"],
        "precision": test_metric["precision"],
        "recall": test_metric["recall"],
        "f1": test_metric["f1"],

        "fpr": fpr,
        "tpr": tpr,
        "pr_precision": precision,
        "pr_recall": recall,
    }


# ============================================================
# 4. 论文图
# ============================================================

def plot_roc(results, outdir):
    plt.figure(figsize=(7, 6))

    for r in results:
        plt.plot(
            r["fpr"],
            r["tpr"],
            label=(
                f"Fold {r['fold']} ROC curve "
                f"(AUC = {r['auc']:.3f})"
            ),
        )

    plt.plot(
        [0, 1],
        [0, 1],
        linestyle="--",
        linewidth=1,
    )

    plt.xlim(0.0, 1.0)
    plt.ylim(0.0, 1.0)
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("Receiver operating characteristic")
    plt.legend(loc="lower right")
    plt.tight_layout()

    plt.savefig(
        outdir / "roc.png",
        dpi=600,
        bbox_inches="tight",
    )

    plt.savefig(
        outdir / "roc.pdf",
        bbox_inches="tight",
    )

    plt.close()


def plot_pr(results, outdir):
    plt.figure(figsize=(7, 6))

    for r in results:
        plt.plot(
            r["pr_recall"],
            r["pr_precision"],
            label=(
                f"Fold {r['fold']} "
                f"AUPR = {r['aupr']:.3f}"
            ),
        )

    plt.xlim(0.0, 1.0)
    plt.ylim(0.0, 1.0)
    plt.xlabel("Recall")
    plt.ylabel("Precision")
    plt.title("Precision-Recall curve")
    plt.legend(loc="lower left")
    plt.tight_layout()

    plt.savefig(
        outdir / "pr.png",
        dpi=600,
        bbox_inches="tight",
    )

    plt.savefig(
        outdir / "pr.pdf",
        bbox_inches="tight",
    )

    plt.close()


# ============================================================
# 5. 论文表
# ============================================================

def make_paper_tables(result_df, outdir):

    metric_cols = [
        "auc",
        "aupr",
        "accuracy",
        "precision",
        "recall",
        "f1",
    ]

    means = result_df[
        metric_cols
    ].mean()

    stds = result_df[
        metric_cols
    ].std(ddof=1)

    # 原始小数表
    raw_table = result_df[
        [
            "fold",
            "auc",
            "aupr",
            "accuracy",
            "precision",
            "recall",
            "f1",
        ]
    ].copy()

    average_row = {
        "fold": "Average",
    }

    std_row = {
        "fold": "Std",
    }

    for c in metric_cols:
        average_row[c] = means[c]
        std_row[c] = stds[c]

    raw_table = pd.concat(
        [
            raw_table,
            pd.DataFrame(
                [average_row, std_row]
            ),
        ],
        ignore_index=True,
    )

    raw_table.to_csv(
        outdir
        / "performance.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # 百分数版，样式接近用户示例
    paper_rows = []

    for _, row in result_df.iterrows():
        paper_rows.append({
            "Fold": int(row["fold"]),
            "AUC": f"{row['auc']*100:.2f}%",
            "AUPR": f"{row['aupr']*100:.2f}%",
            "Accuracy": f"{row['accuracy']*100:.2f}%",
            "Precision": f"{row['precision']*100:.2f}%",
            "Recall": f"{row['recall']*100:.2f}%",
            "F1": f"{row['f1']*100:.2f}%",
        })

    paper_rows.append({
        "Fold": "Average",
        "AUC": f"{means['auc']*100:.2f}%",
        "AUPR": f"{means['aupr']*100:.2f}%",
        "Accuracy": f"{means['accuracy']*100:.2f}%",
        "Precision": f"{means['precision']*100:.2f}%",
        "Recall": f"{means['recall']*100:.2f}%",
        "F1": f"{means['f1']*100:.2f}%",
    })

    paper_table = pd.DataFrame(
        paper_rows
    )

    paper_table.to_csv(
        outdir
        / "performance_percent.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # mean ± std
    summary_lines = [
        "5-fold cross-validation summary",
        "================================",
        f"AUC       = {means['auc']:.4f} ± {stds['auc']:.4f}",
        f"AUPR      = {means['aupr']:.4f} ± {stds['aupr']:.4f}",
        f"Accuracy  = {means['accuracy']:.4f} ± {stds['accuracy']:.4f}",
        f"Precision = {means['precision']:.4f} ± {stds['precision']:.4f}",
        f"Recall    = {means['recall']:.4f} ± {stds['recall']:.4f}",
        f"F1        = {means['f1']:.4f} ± {stds['f1']:.4f}",
    ]

    (
        outdir
        / "metrics.txt"
    ).write_text(
        "\n".join(summary_lines),
        encoding="utf-8",
    )

    # 简单 LaTeX 三线表文本
    latex_lines = [
        r"\begin{table}[htbp]",
        r"\centering",
        r"\caption{Performance of the proposed model under 5-fold cross-validation.}",
        r"\begin{tabular}{ccccccc}",
        r"\toprule",
        r"Fold & AUC & AUPR & Accuracy & Precision & Recall & F1 \\",
        r"\midrule",
    ]

    for row in paper_rows:
        latex_lines.append(
            f"{row['Fold']} & "
            f"{row['AUC']} & "
            f"{row['AUPR']} & "
            f"{row['Accuracy']} & "
            f"{row['Precision']} & "
            f"{row['Recall']} & "
            f"{row['F1']} \\\\"
        )

    latex_lines += [
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{table}",
    ]

    (
        outdir
        / "performance.tex"
    ).write_text(
        "\n".join(latex_lines),
        encoding="utf-8",
    )

    return means, stds, paper_table


# ============================================================
# 6. 主程序
# ============================================================

def main():
    args = parse_args()

    set_seed(args.seed)

    outdir = Path(
        args.outdir
    )

    outdir.mkdir(
        parents=True,
        exist_ok=True,
    )

    device = torch.device(
        "cuda"
        if (
            torch.cuda.is_available()
            and not args.no_cuda
        )
        else "cpu"
    )

    pos = read_edges(
        args.pos_sample
    )

    neg_pool = read_edges(
        args.neg_sample
    )

    mirna_df = pd.read_excel(
        args.mirna_file
    )

    drug_df = pd.read_excel(
        args.drug_file
    )

    dataset_info = {
        "mirnas": int(len(mirna_df)),
        "drugs": int(len(drug_df)),
        "positives": int(len(pos)),
        "negative_pool": int(len(neg_pool)),
    }

    expected = {
        "mirnas": 1314,
        "drugs": 105,
        "positives": 5389,
        "negative_pool": 132581,
    }

    print("=" * 105)
    print(
        "STRATIFIED 5-FOLD CROSS-VALIDATION "
        "— FULL 80 EPOCHS / NO EARLY STOPPING"
    )
    print("=" * 105)

    print("Device :", device)
    print("Dataset:", dataset_info)
    print("Epochs :", args.epochs)
    print("Early stopping: DISABLED")
    print("Validation split: DISABLED")

    if (
        args.strict_final3
        and dataset_info != expected
    ):
        raise RuntimeError(
            "当前数据不是预期 final3 数据集。\n"
            f"actual={dataset_info}\n"
            f"expected={expected}"
        )

    # 固定 1:1 negative benchmark
    rng = np.random.default_rng(
        args.seed
    )

    neg_indices = rng.permutation(
        len(neg_pool)
    )[:len(pos)]

    neg = neg_pool[
        neg_indices
    ].copy()

    X = np.vstack([
        pos,
        neg,
    ]).astype(np.int64)

    y = np.concatenate([
        np.ones(
            len(pos),
            dtype=np.int64,
        ),
        np.zeros(
            len(neg),
            dtype=np.int64,
        ),
    ])

    total_samples = len(X)

    print("\nBalanced benchmark:")
    print("Positive :", int((y == 1).sum()))
    print("Negative :", int((y == 0).sum()))
    print("Total    :", total_samples)

    pd.DataFrame({
        "mirna_idx": X[:, 0],
        "drug_idx": X[:, 1],
        "label": y,
    }).to_csv(
        outdir
        / "samples.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Common post-training probe set shared by all folds.
    # Labels are carried only because Data_class expects a third column;
    # they are NOT used to update the model during weight extraction.
    probe_data = np.column_stack([
        X,
        y,
    ]).astype(np.int64)

    # 特征只加载一次
    drug_features, _ = load_drug_data(
        args.drug_file
    )

    mirna_features, _ = load_mirna_data(
        args.mirna_file
    )

    skf = StratifiedKFold(
        n_splits=5,
        shuffle=True,
        random_state=args.seed,
    )

    all_results = []

    for fold, (
        train_idx,
        test_idx,
    ) in enumerate(
        skf.split(X, y),
        start=1,
    ):

        train_X = X[
            train_idx
        ]

        train_y = y[
            train_idx
        ]

        test_X = X[
            test_idx
        ]

        test_y = y[
            test_idx
        ]

        train_data = np.column_stack([
            train_X,
            train_y,
        ]).astype(np.int64)

        test_data = np.column_stack([
            test_X,
            test_y,
        ]).astype(np.int64)

        train_ratio = (
            len(train_data)
            / total_samples
        )

        test_ratio = (
            len(test_data)
            / total_samples
        )

        print("\n" + "=" * 105)
        print(f"FOLD {fold}/5")
        print("=" * 105)

        print(
            f"Train = {len(train_data)} "
            f"({100*train_ratio:.2f}%)"
        )

        print(
            f"Test  = {len(test_data)} "
            f"({100*test_ratio:.2f}%)"
        )

        print(
            f"Training all {args.epochs} epochs."
        )

        # 保存 exact split
        pd.DataFrame(
            train_data,
            columns=[
                "mirna_idx",
                "drug_idx",
                "label",
            ],
        ).to_csv(
            outdir
            / f"fold{fold}_train.csv",
            index=False,
            encoding="utf-8-sig",
        )

        pd.DataFrame(
            test_data,
            columns=[
                "mirna_idx",
                "drug_idx",
                "label",
            ],
        ).to_csv(
            outdir
            / f"fold{fold}_test.csv",
            index=False,
            encoding="utf-8-sig",
        )

        result = train_one_fold(
            fold=fold,
            train_data=train_data,
            test_data=test_data,
            probe_data=probe_data,
            drug_features=drug_features,
            mirna_features=mirna_features,
            args=args,
            device=device,
            outdir=outdir,
        )

        print(
            f"\nFold {fold} FINAL TEST "
            f"(after epoch {args.epochs}) | "
            f"ACC={result['accuracy']:.4f} | "
            f"AUC={result['auc']:.4f} | "
            f"AUPR={result['aupr']:.4f} | "
            f"Precision={result['precision']:.4f} | "
            f"Recall={result['recall']:.4f} | "
            f"F1={result['f1']:.4f}"
        )

        all_results.append(
            result
        )

    # 汇总五折学习权重：每折先对105种药物求均值，
    # 再以五个fold-level均值计算 mean ± sample SD (ddof=1).
    weight_summaries = [
        r["weight_summary"]
        for r in all_results
    ]
    make_5fold_weight_tables(
        weight_summaries,
        outdir,
    )

    # 去掉曲线数组后保存总结果
    scalar_rows = []

    for r in all_results:

        scalar_rows.append({
            "fold": r["fold"],
            "epochs": r["epochs"],
            "train_pairs": r["train_pairs"],
            "test_pairs": r["test_pairs"],
            "auc": r["auc"],
            "aupr": r["aupr"],
            "accuracy": r["accuracy"],
            "precision": r["precision"],
            "recall": r["recall"],
            "f1": r["f1"],
            "loss": r["loss"],
        })

    result_df = pd.DataFrame(
        scalar_rows
    )

    result_df.to_csv(
        outdir
        / "metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )

    means, stds, paper_table = make_paper_tables(
        result_df,
        outdir,
    )

    plot_roc(
        all_results,
        outdir,
    )

    plot_pr(
        all_results,
        outdir,
    )

    summary = {
        "dataset": dataset_info,
        "balanced_benchmark": {
            "positive": int((y == 1).sum()),
            "negative": int((y == 0).sum()),
            "total": int(total_samples),
        },
        "cross_validation": {
            "method": "StratifiedKFold",
            "n_splits": 5,
            "shuffle": True,
            "random_state": int(args.seed),
            "train_ratio_each_fold": "approximately 80%",
            "test_ratio_each_fold": "approximately 20%",
        },
        "training": {
            "fixed_epochs": int(args.epochs),
            "early_stopping": False,
            "validation_split": False,
            "test_evaluation": "once after the final epoch of each fold",
            "lr": float(args.lr),
            "weight_decay": float(args.weight_decay),
            "batch": int(args.batch),
        },
        "mean": {
            c: float(means[c])
            for c in means.index
        },
        "std": {
            c: float(stds[c])
            for c in stds.index
        },
    }

    with open(
        outdir
        / "summary.json",
        "w",
        encoding="utf-8",
    ) as f:

        json.dump(
            summary,
            f,
            ensure_ascii=False,
            indent=2,
        )

    print("\n" + "=" * 120)
    print("5-FOLD CROSS-VALIDATION FINAL RESULTS")
    print("=" * 120)

    print(
        paper_table.to_string(
            index=False
        )
    )

    print("\nMEAN ± STD")

    print(
        f"AUC       = "
        f"{means['auc']:.4f} ± {stds['auc']:.4f}"
    )

    print(
        f"AUPR      = "
        f"{means['aupr']:.4f} ± {stds['aupr']:.4f}"
    )

    print(
        f"Accuracy  = "
        f"{means['accuracy']:.4f} ± "
        f"{stds['accuracy']:.4f}"
    )

    print(
        f"Precision = "
        f"{means['precision']:.4f} ± "
        f"{stds['precision']:.4f}"
    )

    print(
        f"Recall    = "
        f"{means['recall']:.4f} ± "
        f"{stds['recall']:.4f}"
    )

    print(
        f"F1        = "
        f"{means['f1']:.4f} ± "
        f"{stds['f1']:.4f}"
    )

    print("\nPaper-ready outputs:")
    print(
        outdir
        / "performance_percent.csv"
    )
    print(
        outdir
        / "performance.tex"
    )
    print(
        outdir
        / "roc.png"
    )
    print(
        outdir
        / "roc.pdf"
    )
    print(
        outdir
        / "pr.png"
    )
    print(
        outdir
        / "pr.pdf"
    )
    print(
        outdir
        / "metrics.txt"
    )


if __name__ == "__main__":
    main()
