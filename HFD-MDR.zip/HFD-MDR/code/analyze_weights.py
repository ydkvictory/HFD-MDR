import os
import re
import random
import argparse
from pathlib import Path
from paths import RESULTS_DIR

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader

from sklearn.metrics import accuracy_score, roc_auc_score, average_precision_score

from data import (
    Data_class,
    collate_fn,
    load_drug_data,
    load_mirna_data,
)
from model import DrugMiRNAInteractionModel


FROZEN_BACKBONE_PREFIXES = (
    "mirna_rnafm.model.",
    "drug_chembert.model.",
)


def parse_args():
    p = argparse.ArgumentParser()

    p.add_argument("--pos_sample", required=True)
    p.add_argument("--neg_sample", required=True)
    p.add_argument("--mirna_file", required=True)
    p.add_argument("--drug_file", required=True)

    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--workers", type=int, default=0)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--epochs", type=int, default=80)
    p.add_argument("--lr", type=float, default=5e-4)
    p.add_argument("--weight_decay", type=float, default=5e-4)
    p.add_argument("--dropout", type=float, default=0.5)
    p.add_argument("--entropy_reg_lambda", type=float, default=2e-3)
    p.add_argument("--fusion_temperature", type=float, default=1.5)

    p.add_argument("--outdir", default=str(RESULTS_DIR / "weights"))
    p.add_argument("--top_n", type=int, default=20)
    p.add_argument(
        "--case_ids",
        nargs="*",
        default=["DB00515", "DB01229"],
        help="DrugBank IDs forced into the selected heatmap when present.",
    )
    p.add_argument("--strict_final3", action="store_true")
    p.add_argument("--no_cuda", action="store_true", default=False)

    # Keep consistent with the current project / config.py.
    p.add_argument("--drug_input_dim", type=int, default=69)
    p.add_argument("--drug_hidden_dim", type=int, default=128)
    p.add_argument("--drug_feature_dim", type=int, default=128)
    p.add_argument("--mirna_feature_dim", type=int, default=128)

    p.add_argument("--drug_desc_dim", type=int, default=64)
    p.add_argument("--drug_fp_dim", type=int, default=256)

    p.add_argument("--drug_admet_dim", type=int, default=21)
    p.add_argument("--drug_target_raw_dim", type=int, default=523)

    p.add_argument("--admet_token_dim", type=int, default=128)
    p.add_argument("--admet_num_heads", type=int, default=4)
    p.add_argument("--admet_num_layers", type=int, default=1)

    p.add_argument("--target_concept_dim", type=int, default=128)
    p.add_argument("--target_topk", type=int, default=12)
    p.add_argument("--target_num_heads", type=int, default=4)
    p.add_argument("--target_num_layers", type=int, default=1)

    return p.parse_args()


def set_seed(seed):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def read_edges(path):
    x = np.loadtxt(path, dtype=np.int64)

    if x.ndim == 1:
        x = x.reshape(1, -1)

    if x.shape[1] != 2:
        raise ValueError(f"{path} must contain exactly two columns")

    return x


def make_loader(data, drug_features, mirna_features, args, shuffle):
    dataset = Data_class(
        data,
        drug_features=drug_features,
        mirna_features=mirna_features,
    )

    generator = torch.Generator()
    generator.manual_seed(args.seed)

    return DataLoader(
        dataset,
        batch_size=args.batch,
        shuffle=shuffle,
        num_workers=args.workers,
        collate_fn=collate_fn,
        drop_last=False,
        generator=generator if shuffle else None,
    )


def safe_metrics(y, p):
    y = np.asarray(y, dtype=int)
    p = np.asarray(p, dtype=float)
    pred = (p >= 0.5).astype(int)

    return {
        "acc": accuracy_score(y, pred),
        "auc": roc_auc_score(y, p),
        "aupr": average_precision_score(y, p),
    }


def get_light_state(model):
    return {
        k: v.detach().cpu().clone()
        for k, v in model.state_dict().items()
        if not k.startswith(FROZEN_BACKBONE_PREFIXES)
    }


def describe_object(obj, prefix="fusion_info"):
    lines = []

    def walk(x, name):
        if torch.is_tensor(x):
            lines.append(
                f"{name}: Tensor shape={tuple(x.shape)} dtype={x.dtype}"
            )
        elif isinstance(x, dict):
            lines.append(f"{name}: dict keys={list(x.keys())}")
            for k, v in x.items():
                walk(v, f"{name}.{k}")
        elif isinstance(x, (list, tuple)):
            lines.append(f"{name}: {type(x).__name__} len={len(x)}")
            for i, v in enumerate(x):
                walk(v, f"{name}[{i}]")
        else:
            lines.append(
                f"{name}: {type(x).__name__} value={repr(x)[:160]}"
            )

    walk(obj, prefix)
    return "\n".join(lines)


def find_4weight_candidates(fusion_info, batch_size):
    candidates = []

    def walk(x, name):
        if torch.is_tensor(x):
            arr = x.detach().cpu()

            if (
                arr.ndim == 2
                and arr.shape[0] == batch_size
                and arr.shape[1] == 4
            ):
                row_sum = arr.float().sum(dim=1).numpy()

                candidates.append({
                    "name": name,
                    "tensor": arr.float(),
                    "mean_row_sum": float(np.mean(row_sum)),
                    "max_sum_error": float(
                        np.max(np.abs(row_sum - 1.0))
                    ),
                })

        elif isinstance(x, dict):
            for k, v in x.items():
                walk(v, f"{name}.{k}")

        elif isinstance(x, (list, tuple)):
            for i, v in enumerate(x):
                walk(v, f"{name}[{i}]")

    walk(fusion_info, "fusion_info")
    return candidates


def select_4weights(fusion_info, batch_size):
    candidates = find_4weight_candidates(
        fusion_info,
        batch_size,
    )

    if not candidates:
        raise RuntimeError(
            "No [batch,4] fusion-weight tensor was found.\n"
            "Check weight_heatmap_results/fusion_structure.txt."
        )

    # The current model historically prints total/effective four-modality weights.
    keywords = [
        "total",
        "effective",
        "final",
        "overall",
        "weight",
    ]

    for item in candidates:
        n = item["name"].lower()
        item["priority"] = sum(
            word in n for word in keywords
        )

        # Strong preference for a normalized 4-modal vector.
        if item["max_sum_error"] <= 5e-3:
            item["priority"] += 10

    candidates.sort(
        key=lambda x: (
            x["priority"],
            -x["max_sum_error"],
        ),
        reverse=True,
    )

    best = candidates[0]

    if best["max_sum_error"] > 5e-2:
        details = "\n".join(
            f"{x['name']} | mean_sum={x['mean_row_sum']:.6f} "
            f"| max_error={x['max_sum_error']:.6f}"
            for x in candidates
        )

        raise RuntimeError(
            "A [batch,4] tensor was found, but it does not look like "
            "normalized effective modality weights.\n"
            + details
            + "\nSend fusion_structure.txt and "
              "weight_candidates.txt for adjustment."
        )

    return best, candidates


def save_candidate_report(candidates, path):
    lines = []

    for x in candidates:
        lines.append(
            f"{x['name']} | "
            f"mean_row_sum={x['mean_row_sum']:.8f} | "
            f"max_sum_error={x['max_sum_error']:.8f}"
        )

    path.write_text(
        "\n".join(lines),
        encoding="utf-8",
    )


def model_forward(model, batch, device):
    outputs, fusion_info, entropy_reg = model(
        batch["drug_graphs"],
        batch["drug_smiles"],
        batch["drug_desc"].to(device),
        batch["drug_fp"].to(device),
        batch["drug_admet"].to(device),
        batch["drug_target_pathway"].to(device),
        batch["mirna_encoded"].to(device),
        batch["mirna_seqs"],
    )

    outputs = torch.nan_to_num(
        outputs,
        nan=0.5,
        posinf=1.0,
        neginf=0.0,
    )

    outputs = torch.clamp(
        outputs,
        min=1e-6,
        max=1.0 - 1e-6,
    )

    labels = batch["labels"].to(device)

    return outputs, labels, fusion_info, entropy_reg


def train_interpretation_model(
    model,
    loader,
    args,
    device,
    outdir,
):
    criterion = nn.BCELoss()

    optimizer = optim.Adam(
        filter(
            lambda p: p.requires_grad,
            model.parameters(),
        ),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    history = []
    structure_saved = False
    candidate_saved = False

    for epoch in range(
        1,
        args.epochs + 1,
    ):
        model.train()

        labels_all = []
        probs_all = []

        bce_sum = 0.0
        entropy_sum = 0.0
        n_samples = 0

        four_sum = np.zeros(
            4,
            dtype=float,
        )
        four_n = 0

        for batch in loader:
            outputs, labels, fusion_info, entropy_reg = model_forward(
                model,
                batch,
                device,
            )

            bs = labels.size(0)

            if not structure_saved:
                structure = describe_object(
                    fusion_info
                )

                (
                    outdir
                    / "fusion_structure.txt"
                ).write_text(
                    structure,
                    encoding="utf-8",
                )

                print("\nFusion info structure:")
                print(structure)

                structure_saved = True

            best, candidates = select_4weights(
                fusion_info,
                bs,
            )

            if not candidate_saved:
                save_candidate_report(
                    candidates,
                    outdir
                    / "weight_candidates.txt",
                )

                print(
                    "\nSelected 4-weight tensor:",
                    best["name"],
                )

                candidate_saved = True

            weights = best["tensor"]

            bce = criterion(
                outputs,
                labels,
            )

            loss = (
                bce
                - args.entropy_reg_lambda
                * entropy_reg
            )

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            bce_sum += float(
                bce.item()
            ) * bs

            entropy_sum += float(
                entropy_reg.item()
            ) * bs

            n_samples += bs

            labels_all.extend(
                labels.detach().cpu().numpy().tolist()
            )

            probs_all.extend(
                outputs.detach().cpu().numpy().tolist()
            )

            four_sum += (
                weights.numpy()
                .sum(axis=0)
            )
            four_n += bs

        m = safe_metrics(
            labels_all,
            probs_all,
        )

        mean_w = (
            four_sum
            / max(four_n, 1)
        )

        history.append({
            "epoch": epoch,
            "train_bce": (
                bce_sum
                / max(n_samples, 1)
            ),
            "train_entropy": (
                entropy_sum
                / max(n_samples, 1)
            ),
            "train_acc": m["acc"],
            "train_auc": m["auc"],
            "train_aupr": m["aupr"],
            "mean_SMILES": mean_w[0],
            "mean_Graph": mean_w[1],
            "mean_ADMET": mean_w[2],
            "mean_Target": mean_w[3],
            "mean_Chemical": (
                mean_w[0]
                + mean_w[1]
            ),
            "mean_Mechanism": (
                mean_w[2]
                + mean_w[3]
            ),
        })

        print(
            f"Epoch {epoch:03d}/{args.epochs} | "
            f"BCE={bce_sum/max(n_samples,1):.4f} | "
            f"AUC={m['auc']:.4f} "
            f"AUPR={m['aupr']:.4f} | "
            f"Weights [SMILES, Graph, ADMET, Target]="
            f"[{mean_w[0]:.3f}, "
            f"{mean_w[1]:.3f}, "
            f"{mean_w[2]:.3f}, "
            f"{mean_w[3]:.3f}]"
        )

    pd.DataFrame(
        history
    ).to_csv(
        outdir
        / "history.csv",
        index=False,
        encoding="utf-8-sig",
    )

    torch.save(
        {
            "seed": args.seed,
            "epochs": args.epochs,
            "state_dict": get_light_state(
                model
            ),
        },
        outdir
        / "final_interpretation_model_light.pt",
    )


def export_pair_weights(
    model,
    loader,
    device,
    outdir,
):
    model.eval()

    rows = []
    selected_name = None

    with torch.no_grad():
        for batch in loader:
            outputs, labels, fusion_info, _ = model_forward(
                model,
                batch,
                device,
            )

            bs = labels.size(0)

            best, _ = select_4weights(
                fusion_info,
                bs,
            )

            selected_name = best["name"]

            w = best[
                "tensor"
            ].numpy()

            mirna_idx = (
                batch["mirna_indices"]
                .cpu()
                .numpy()
                .astype(int)
            )

            drug_idx = (
                batch["drug_indices"]
                .cpu()
                .numpy()
                .astype(int)
            )

            for i in range(bs):
                smiles = float(w[i, 0])
                graph = float(w[i, 1])
                admet = float(w[i, 2])
                target = float(w[i, 3])

                rows.append({
                    "mirna_idx": int(
                        mirna_idx[i]
                    ),
                    "drug_idx": int(
                        drug_idx[i]
                    ),
                    "label": int(
                        labels[i].item()
                    ),
                    "pred_prob": float(
                        outputs[i].item()
                    ),
                    "SMILES": smiles,
                    "Graph": graph,
                    "ADMET": admet,
                    "Target": target,
                    "Chemical": (
                        smiles
                        + graph
                    ),
                    "Mechanism": (
                        admet
                        + target
                    ),
                    "weight_sum": (
                        smiles
                        + graph
                        + admet
                        + target
                    ),
                })

    pair_df = pd.DataFrame(
        rows
    )

    pair_df.to_csv(
        outdir
        / "pair_weights.csv",
        index=False,
        encoding="utf-8-sig",
    )

    return pair_df, selected_name


def identify_drug_columns(df):
    idx_col = None
    id_col = None
    name_col = None

    # Detect numeric drug index column.
    for col in df.columns:
        x = pd.to_numeric(
            df[col],
            errors="coerce",
        )

        if x.notna().all():
            vals = x.astype(
                int
            ).to_numpy()

            if (
                len(np.unique(vals))
                == len(vals)
                and vals.min() >= 0
            ):
                if idx_col is None:
                    idx_col = col

                if str(col).lower() in {
                    "drug_idx",
                    "index",
                    "idx",
                }:
                    idx_col = col
                    break

    # Detect DrugBank ID column.
    for col in df.columns:
        vals = (
            df[col]
            .astype(str)
            .str.strip()
        )

        ratio = vals.str.match(
            r"^DB\d+$",
            na=False,
        ).mean()

        if ratio > 0.5:
            id_col = col
            break

    # Detect name column when present.
    for candidate in [
        "drug_name",
        "Drug_Name",
        "name",
        "Name",
    ]:
        if candidate in df.columns:
            name_col = candidate
            break

    return idx_col, id_col, name_col


def make_drug_mapping(drug_file):
    df = pd.read_excel(
        drug_file
    )

    idx_col, id_col, name_col = identify_drug_columns(
        df
    )

    if idx_col is None:
        drug_idx = np.arange(
            len(df),
            dtype=int,
        )
    else:
        drug_idx = pd.to_numeric(
            df[idx_col],
            errors="raise",
        ).astype(
            int
        ).to_numpy()

    if id_col is None:
        drugbank = np.array([
            f"Drug_{i}"
            for i in drug_idx
        ])
    else:
        drugbank = (
            df[id_col]
            .astype(str)
            .str.strip()
            .to_numpy()
        )

    if name_col is None:
        drug_name = drugbank.copy()
    else:
        drug_name = (
            df[name_col]
            .astype(str)
            .str.strip()
            .to_numpy()
        )

    return pd.DataFrame({
        "drug_idx": drug_idx,
        "DrugBank_ID": drugbank,
        "Drug_Name": drug_name,
    })


def aggregate_drug_weights(
    pair_df,
    drug_file,
):
    modality_cols = [
        "SMILES",
        "Graph",
        "ADMET",
        "Target",
        "Chemical",
        "Mechanism",
        "weight_sum",
    ]

    mean_df = (
        pair_df.groupby(
            "drug_idx",
            as_index=False,
        )[modality_cols]
        .mean()
    )

    std_df = (
        pair_df.groupby(
            "drug_idx",
            as_index=False,
        )[
            [
                "SMILES",
                "Graph",
                "ADMET",
                "Target",
            ]
        ]
        .std(
            ddof=0
        )
        .fillna(0.0)
        .rename(
            columns={
                "SMILES": "SMILES_pair_std",
                "Graph": "Graph_pair_std",
                "ADMET": "ADMET_pair_std",
                "Target": "Target_pair_std",
            }
        )
    )

    counts = (
        pair_df.groupby(
            "drug_idx"
        )
        .size()
        .rename(
            "n_pairs"
        )
        .reset_index()
    )

    mapping = make_drug_mapping(
        drug_file
    )

    out = (
        mean_df
        .merge(
            std_df,
            on="drug_idx",
            how="left",
        )
        .merge(
            counts,
            on="drug_idx",
            how="left",
        )
        .merge(
            mapping,
            on="drug_idx",
            how="left",
        )
    )

    return out


def select_representative(
    drug_df,
    top_n,
    case_ids,
):
    selected = []

    def add(index_values):
        for idx in index_values:
            idx = int(idx)

            if idx not in selected:
                selected.append(
                    idx
                )

            if len(selected) >= top_n:
                return

    # Force case-study drugs when available.
    mask = (
        drug_df["DrugBank_ID"]
        .astype(str)
        .isin(case_ids)
    )

    add(
        drug_df.index[
            mask
        ].tolist()
    )

    n_block = max(
        4,
        top_n // 3,
    )

    # Chemical-dominant.
    add(
        drug_df.sort_values(
            "Chemical",
            ascending=False,
        ).head(
            n_block
        ).index.tolist()
    )

    # Mechanism-dominant.
    add(
        drug_df.sort_values(
            "Mechanism",
            ascending=False,
        ).head(
            n_block
        ).index.tolist()
    )

    # Balanced Chemical/Mechanism.
    balance = (
        drug_df["Chemical"]
        - drug_df["Mechanism"]
    ).abs()

    add(
        balance.sort_values(
            ascending=True
        ).head(
            top_n
        ).index.tolist()
    )

    if len(selected) < top_n:
        add(
            drug_df.index.tolist()
        )

    return (
        drug_df.loc[
            selected[:top_n]
        ]
        .copy()
        .reset_index(
            drop=True
        )
    )


def make_row_labels(df):
    labels = []

    for _, row in df.iterrows():
        dbid = str(
            row["DrugBank_ID"]
        )

        name = str(
            row["Drug_Name"]
        )

        if (
            name
            and name.lower() != "nan"
            and name != dbid
        ):
            labels.append(
                f"{name} ({dbid})"
            )
        else:
            labels.append(
                dbid
            )

    return labels


def plot_heatmap(
    df,
    columns,
    title,
    png_path,
    pdf_path,
    annotate=True,
):
    matrix = (
        df[columns]
        .to_numpy(
            dtype=float
        )
    )

    labels = make_row_labels(
        df
    )

    fig_height = max(
        6.0,
        0.36 * len(df)
        + 1.6,
    )

    fig_width = (
        7.4
        if len(columns) == 4
        else 5.8
    )

    fig, ax = plt.subplots(
        figsize=(
            fig_width,
            fig_height,
        )
    )

    image = ax.imshow(
        matrix,
        aspect="auto",
        vmin=0.0,
        vmax=1.0,
    )

    ax.set_xticks(
        np.arange(
            len(columns)
        )
    )

    ax.set_xticklabels(
        columns
    )

    ax.set_yticks(
        np.arange(
            len(labels)
        )
    )

    ax.set_yticklabels(
        labels,
        fontsize=(
            8
            if len(df) <= 25
            else 5
        ),
    )

    ax.set_xlabel(
        "Feature modality"
    )

    ax.set_ylabel(
        "Drug"
    )

    ax.set_title(
        title
    )

    if annotate:
        for i in range(
            matrix.shape[0]
        ):
            for j in range(
                matrix.shape[1]
            ):
                ax.text(
                    j,
                    i,
                    f"{matrix[i,j]:.3f}",
                    ha="center",
                    va="center",
                    fontsize=7,
                )

    fig.colorbar(
        image,
        ax=ax,
        label="Learned weight",
    )

    fig.tight_layout()

    fig.savefig(
        png_path,
        dpi=600,
        bbox_inches="tight",
    )

    fig.savefig(
        pdf_path,
        bbox_inches="tight",
    )

    plt.close(
        fig
    )


def main():
    args = parse_args()

    set_seed(
        args.seed
    )

    outdir = Path(
        args.outdir
    )

    outdir.mkdir(
        parents=True,
        exist_ok=True,
    )

    device = torch.device(
        "cuda"
        if (
            torch.cuda.is_available()
            and not args.no_cuda
        )
        else "cpu"
    )

    pos = read_edges(
        args.pos_sample
    )

    neg_pool = read_edges(
        args.neg_sample
    )

    mirna_df = pd.read_excel(
        args.mirna_file
    )

    drug_df_raw = pd.read_excel(
        args.drug_file
    )

    current = {
        "miRNAs": len(
            mirna_df
        ),
        "drugs": len(
            drug_df_raw
        ),
        "positive": len(
            pos
        ),
        "negative_pool": len(
            neg_pool
        ),
    }

    expected = {
        "miRNAs": 1314,
        "drugs": 105,
        "positive": 5389,
        "negative_pool": 132581,
    }

    print("=" * 104)
    print("HFD-MDR DRUG WEIGHT HEATMAP ANALYSIS")
    print("=" * 104)

    print(
        "Device :",
        device,
    )

    print(
        "Dataset:",
        current,
    )

    if (
        args.strict_final3
        and current != expected
    ):
        raise RuntimeError(
            "Final dataset check failed.\n"
            f"actual   = {current}\n"
            f"expected = {expected}"
        )

    # Fixed balanced interpretation benchmark.
    rng = np.random.default_rng(
        args.seed
    )

    neg_indices = rng.permutation(
        len(neg_pool)
    )[
        :len(pos)
    ]

    neg = neg_pool[
        neg_indices
    ].copy()

    positive = np.column_stack([
        pos,
        np.ones(
            len(pos),
            dtype=np.int64,
        ),
    ])

    negative = np.column_stack([
        neg,
        np.zeros(
            len(neg),
            dtype=np.int64,
        ),
    ])

    full_data = np.vstack([
        positive,
        negative,
    ]).astype(
        np.int64
    )

    rng.shuffle(
        full_data
    )

    print("\nInterpretation training set:")
    print(
        "Positive:",
        len(pos),
    )
    print(
        "Negative:",
        len(neg),
    )
    print(
        "Total   :",
        len(full_data),
    )

    drug_features, valid_drugs = load_drug_data(
        args.drug_file
    )

    mirna_features, valid_mirnas = load_mirna_data(
        args.mirna_file
    )

    print(
        "Loaded drugs :",
        len(valid_drugs),
    )

    print(
        "Loaded miRNAs:",
        len(valid_mirnas),
    )

    train_loader = make_loader(
        full_data,
        drug_features,
        mirna_features,
        args,
        shuffle=True,
    )

    export_loader = make_loader(
        full_data,
        drug_features,
        mirna_features,
        args,
        shuffle=False,
    )

    model = DrugMiRNAInteractionModel(
        args
    ).to(
        device
    )

    print(
        "\nTraining dedicated interpretation model..."
    )

    train_interpretation_model(
        model,
        train_loader,
        args,
        device,
        outdir,
    )

    print(
        "\nExtracting learned weights..."
    )

    pair_df, tensor_name = export_pair_weights(
        model,
        export_loader,
        device,
        outdir,
    )

    drug_weights = aggregate_drug_weights(
        pair_df,
        args.drug_file,
    )

    # Sort by drug_idx for the complete table.
    drug_weights = drug_weights.sort_values(
        "drug_idx"
    ).reset_index(
        drop=True
    )

    drug_weights.to_csv(
        outdir
        / "drug_weights.csv",
        index=False,
        encoding="utf-8-sig",
    )

    selected = select_representative(
        drug_weights,
        args.top_n,
        args.case_ids,
    )

    selected.to_csv(
        outdir
        / "selected_weights.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Main figure A: selected 20 × 4
    plot_heatmap(
        selected,
        [
            "SMILES",
            "Graph",
            "ADMET",
            "Target",
        ],
        "Learned weights of drug feature modalities",
        outdir
        / "selected_modalities.png",
        outdir
        / "selected_modalities.pdf",
        annotate=True,
    )

    # Main figure B: selected 20 × 2
    plot_heatmap(
        selected,
        [
            "Chemical",
            "Mechanism",
        ],
        "Learned weights of hierarchical drug feature layers",
        outdir
        / "layer_weights.png",
        outdir
        / "layer_weights.pdf",
        annotate=True,
    )

    # Supplementary full 105 × 4.
    plot_heatmap(
        drug_weights,
        [
            "SMILES",
            "Graph",
            "ADMET",
            "Target",
        ],
        "Learned weights across all drugs",
        outdir
        / "modality_weights.png",
        outdir
        / "modality_weights.pdf",
        annotate=False,
    )

    mean_weights = (
        drug_weights[
            [
                "SMILES",
                "Graph",
                "ADMET",
                "Target",
                "Chemical",
                "Mechanism",
            ]
        ]
        .mean()
    )

    pair_std_cols = [
        "SMILES_pair_std",
        "Graph_pair_std",
        "ADMET_pair_std",
        "Target_pair_std",
    ]

    max_pair_std = float(
        drug_weights[
            pair_std_cols
        ].to_numpy(
            dtype=float
        ).max()
    )

    max_sum_error = float(
        np.max(
            np.abs(
                drug_weights[
                    "weight_sum"
                ].to_numpy(
                    dtype=float
                )
                - 1.0
            )
        )
    )

    summary = [
        "HFD-MDR drug weight heatmap analysis",
        "====================================",
        f"Selected fusion tensor: {tensor_name}",
        f"Number of drugs: {len(drug_weights)}",
        f"Number of interpretation pairs: {len(pair_df)}",
        f"Max |four-weight sum - 1|: {max_sum_error:.8f}",
        f"Max within-drug pair-level weight std: {max_pair_std:.8f}",
        "",
        "Mean effective weights across drugs:",
        f"SMILES    = {mean_weights['SMILES']:.6f}",
        f"Graph     = {mean_weights['Graph']:.6f}",
        f"ADMET     = {mean_weights['ADMET']:.6f}",
        f"Target    = {mean_weights['Target']:.6f}",
        f"Chemical  = {mean_weights['Chemical']:.6f}",
        f"Mechanism = {mean_weights['Mechanism']:.6f}",
        "",
        "Selected main-text drugs:",
    ]

    for _, row in selected.iterrows():
        summary.append(
            f"{row['DrugBank_ID']} | "
            f"SMILES={row['SMILES']:.4f} "
            f"Graph={row['Graph']:.4f} "
            f"ADMET={row['ADMET']:.4f} "
            f"Target={row['Target']:.4f} "
            f"Chemical={row['Chemical']:.4f} "
            f"Mechanism={row['Mechanism']:.4f}"
        )

    (
        outdir
        / "summary.txt"
    ).write_text(
        "\n".join(
            summary
        ),
        encoding="utf-8",
    )

    print("\n" + "=" * 104)
    print("WEIGHT ANALYSIS COMPLETED")
    print("=" * 104)

    print(
        "Selected fusion tensor:",
        tensor_name,
    )

    print(
        f"Max |weight sum - 1| = "
        f"{max_sum_error:.8f}"
    )

    print(
        f"Max within-drug weight std = "
        f"{max_pair_std:.8f}"
    )

    print("\nMean effective weights:")
    print(
        mean_weights.to_string()
    )

    print("\nSaved:")
    for name in [
        "drug_weights.csv",
        "selected_weights.csv",
        "summary.txt",
        "selected_modalities.png",
        "layer_weights.png",
        "modality_weights.png",
    ]:
        print(
            outdir / name
        )


if __name__ == "__main__":
    main()
