from paths import CHEMBERTA_DIR

import warnings
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv, global_mean_pool, global_max_pool
from torch_geometric.data import Batch
from transformers import AutoTokenizer, AutoModel
import numpy as np
import fm
from transformers import logging

logging.set_verbosity_error()
warnings.filterwarnings('ignore', category=UserWarning, module='torch_geometric')


# =========================
# miRNA side: masked token-level bidirectional cross-attention
# =========================

class CNNFeatureExtractor(nn.Module):
    def __init__(self, output_dim, vocab_size=5, embed_dim=128,
                 num_filters=64, filter_sizes=(2, 3, 4)):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        self.convs = nn.ModuleList([
            nn.Conv1d(embed_dim, num_filters, kernel_size=k)
            for k in filter_sizes
        ])
        self.dropout = nn.Dropout(0.2)
        self.fc = nn.Linear(len(filter_sizes) * num_filters, output_dim)
        self.token_projections = nn.ModuleList([
            nn.Linear(num_filters, output_dim) for _ in filter_sizes
        ])

    def forward(self, x, return_tokens=False):
        valid_bases = x.ne(0)
        embedded = self.embedding(x).transpose(1, 2)
        pooled_features, token_features, token_masks = [], [], []

        for conv, projection in zip(self.convs, self.token_projections):
            local = F.relu(conv(embedded))
            kernel_size = conv.kernel_size[0]
            valid_windows = valid_bases.unfold(1, kernel_size, 1).all(dim=-1)

            pooled = local.masked_fill(
                ~valid_windows.unsqueeze(1), float("-inf")
            ).amax(dim=2)
            pooled = torch.where(
                valid_windows.any(dim=1, keepdim=True),
                pooled, torch.zeros_like(pooled)
            )
            pooled_features.append(pooled)

            tokens = projection(local.transpose(1, 2))
            tokens = tokens.masked_fill(~valid_windows.unsqueeze(-1), 0.0)
            token_features.append(tokens)
            token_masks.append(valid_windows)

        features = self.fc(self.dropout(torch.cat(pooled_features, dim=1)))
        if not return_tokens:
            return features
        tokens = torch.cat(token_features, dim=1)
        valid_mask = torch.cat(token_masks, dim=1)
        return features, tokens, valid_mask


class RNAFMFeatureExtractor(nn.Module):
    def __init__(self, output_dim, model_layer=12):
        super(RNAFMFeatureExtractor, self).__init__()

        self.model, self.alphabet = fm.pretrained.rna_fm_t12()
        self.batch_converter = self.alphabet.get_batch_converter()
        self.model.eval()

        for param in self.model.parameters():
            param.requires_grad = False

        self.model_layer = model_layer
        self.rna_fm_dim = 640
        self.projection = nn.Linear(self.rna_fm_dim, output_dim)
        self.dropout = nn.Dropout(0.2)

    def forward(self, rna_sequence, return_tokens=False):
        if isinstance(rna_sequence, list) and isinstance(rna_sequence[0], str):
            rna_sequence = [(f"seq_{i}", seq) for i, seq in enumerate(rna_sequence)]

        device = self.projection.weight.device
        _, _, batch_tokens = self.batch_converter(rna_sequence)
        batch_tokens = batch_tokens.to(device)

        with torch.no_grad():
            results = self.model(batch_tokens, repr_layers=[self.model_layer])
            token_embeddings = results["representations"][self.model_layer]
            valid_mask = batch_tokens.ne(self.alphabet.padding_idx)
            for name in ("cls_idx", "bos_idx", "eos_idx"):
                index = getattr(self.alphabet, name, None)
                if index is not None:
                    valid_mask = valid_mask & batch_tokens.ne(int(index))
            mask = valid_mask.unsqueeze(-1).to(token_embeddings.dtype)
            pooled = (token_embeddings * mask).sum(dim=1)
            pooled = pooled / mask.sum(dim=1).clamp_min(1.0)

        features = self.dropout(self.projection(pooled))
        if not return_tokens:
            return features
        tokens = self.projection(token_embeddings)
        tokens = tokens.masked_fill(~valid_mask.unsqueeze(-1), 0.0)
        return features, tokens, valid_mask


class CrossAttention(nn.Module):
    def __init__(self, d_model, num_heads=2):
        super(CrossAttention, self).__init__()
        self.d_model = d_model
        self.num_heads = num_heads
        self.head_dim = d_model // num_heads

        self.query = nn.Linear(d_model, d_model)
        self.key = nn.Linear(d_model, d_model)
        self.value = nn.Linear(d_model, d_model)

        self.out_proj = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(0.1)

    def forward(self, query, key, value, key_valid_mask=None):
        # key_valid_mask uses True for valid keys and False for padding.
        batch_size = query.size(0)
        Q = self.query(query).reshape(
            batch_size, -1, self.num_heads, self.head_dim
        ).transpose(1, 2)
        K = self.key(key).reshape(
            batch_size, -1, self.num_heads, self.head_dim
        ).transpose(1, 2)
        V = self.value(value).reshape(
            batch_size, -1, self.num_heads, self.head_dim
        ).transpose(1, 2)

        scores = torch.matmul(Q, K.transpose(-2, -1)) / (self.head_dim ** 0.5)
        if key_valid_mask is not None:
            key_valid_mask = key_valid_mask.to(device=scores.device, dtype=torch.bool)
            if not key_valid_mask.any(dim=1).all().item():
                raise ValueError("Each sequence must contain at least one valid key token.")
            scores = scores.masked_fill(
                ~key_valid_mask[:, None, None, :], float("-inf")
            )

        weights = self.dropout(F.softmax(scores, dim=-1))
        context = torch.matmul(weights, V)
        context = context.transpose(1, 2).contiguous().reshape(
            batch_size, query.size(1), self.d_model
        )
        return self.out_proj(context)


class FeatureFusion(nn.Module):
    def __init__(self, feature_dim):
        super(FeatureFusion, self).__init__()
        self.cross_attention = CrossAttention(feature_dim)
        self.layer_norm = nn.LayerNorm(feature_dim)

        self.ffn = nn.Sequential(
            nn.Linear(feature_dim, feature_dim * 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(feature_dim * 2, feature_dim)
        )

    def forward(self, f1, f2, tokens1, tokens2, mask1, mask2):
        # Each pooled vector queries valid tokens from the opposite branch.
        attended_f1 = self.cross_attention(
            f1.unsqueeze(1), tokens2, tokens2, key_valid_mask=mask2
        ).squeeze(1)
        attended_f2 = self.cross_attention(
            f2.unsqueeze(1), tokens1, tokens1, key_valid_mask=mask1
        ).squeeze(1)
        f1_out = self.layer_norm(f1 + attended_f1)
        f2_out = self.layer_norm(f2 + attended_f2)
        return f1_out + f2_out


# =========================
# drug chemical side: 保持不变
# =========================

class GCNFeatureExtractor(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_layers=3):
        super(GCNFeatureExtractor, self).__init__()

        self.convs = nn.ModuleList()
        self.convs.append(GCNConv(input_dim, hidden_dim))
        for _ in range(num_layers - 2):
            self.convs.append(GCNConv(hidden_dim, hidden_dim))
        self.convs.append(GCNConv(hidden_dim, output_dim))

        self.dropout = nn.Dropout(0.2)
        self.batch_norm = nn.ModuleList([nn.BatchNorm1d(hidden_dim) for _ in range(num_layers - 1)])
        self.batch_norm.append(nn.BatchNorm1d(output_dim))

    def forward(self, x, edge_index, batch):
        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index)
            x = self.batch_norm[i](x)

            if i < len(self.convs) - 1:
                x = F.relu(x)
                x = self.dropout(x)

        x = global_mean_pool(x, batch) + global_max_pool(x, batch)
        return x


class ChemBERTaFeatureExtractor(nn.Module):
    def __init__(self, output_dim):
        super(ChemBERTaFeatureExtractor, self).__init__()
        self.tokenizer = AutoTokenizer.from_pretrained(str(CHEMBERTA_DIR))
        self.model = AutoModel.from_pretrained(str(CHEMBERTA_DIR))

        for param in self.model.parameters():
            param.requires_grad = False

        self.projection = nn.Linear(self.model.config.hidden_size, output_dim)
        self.dropout = nn.Dropout(0.2)

    def forward(self, smiles_list):
        encoded = self.tokenizer(
            smiles_list,
            padding=True,
            truncation=True,
            max_length=512,
            return_tensors='pt',
            return_special_tokens_mask=True
        )

        device = next(self.model.parameters()).device

        # special_tokens_mask is used only for pooling and must not be passed to the model.
        special_tokens_mask = encoded.pop("special_tokens_mask").to(device)
        encoded = {k: v.to(device) for k, v in encoded.items()}

        with torch.no_grad():
            outputs = self.model(**encoded)

        token_embeddings = outputs.last_hidden_state

        # Masked mean pooling over valid SMILES tokens.
        # Both padding and tokenizer special tokens are excluded.
        valid_mask = encoded["attention_mask"].bool() & (~special_tokens_mask.bool())
        mask = valid_mask.unsqueeze(-1).to(token_embeddings.dtype)
        denom = mask.sum(dim=1).clamp_min(1.0)
        pooled_embeddings = (token_embeddings * mask).sum(dim=1) / denom

        features = self.projection(pooled_embeddings)
        features = self.dropout(features)
        return features


# =========================
# mechanism side: 增强模块
# =========================

class LightTransformerBlock(nn.Module):
    def __init__(self, dim, num_heads=4, dropout=0.1, ff_mult=2):
        super(LightTransformerBlock, self).__init__()
        self.attn = nn.MultiheadAttention(
            embed_dim=dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True
        )
        self.norm1 = nn.LayerNorm(dim)
        self.ffn = nn.Sequential(
            nn.Linear(dim, dim * ff_mult),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(dim * ff_mult, dim)
        )
        self.norm2 = nn.LayerNorm(dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, key_padding_mask=None):
        attn_out, _ = self.attn(
            x, x, x,
            key_padding_mask=key_padding_mask,
            need_weights=False
        )
        x = self.norm1(x + self.dropout(attn_out))
        ffn_out = self.ffn(x)
        x = self.norm2(x + self.dropout(ffn_out))
        return x


class FeatureTokenizer(nn.Module):
    def __init__(self, num_features, token_dim):
        super(FeatureTokenizer, self).__init__()
        self.value_scale = nn.Parameter(torch.randn(num_features, token_dim) * 0.02)
        self.feature_bias = nn.Parameter(torch.randn(num_features, token_dim) * 0.02)

    def forward(self, x):
        return x.unsqueeze(-1) * self.value_scale.unsqueeze(0) + self.feature_bias.unsqueeze(0)


class ContextAwareAttentionPool(nn.Module):
    def __init__(self, input_dim, context_dim=None):
        super(ContextAwareAttentionPool, self).__init__()
        self.token_proj = nn.Linear(input_dim, input_dim)
        self.score_proj = nn.Linear(input_dim, 1, bias=False)
        self.context_proj = nn.Linear(context_dim, input_dim, bias=False) if context_dim is not None else None

    def forward(self, tokens, valid_mask=None, context=None):
        h = torch.tanh(self.token_proj(tokens))
        if context is not None and self.context_proj is not None:
            h = h + self.context_proj(context).unsqueeze(1)

        scores = self.score_proj(h).squeeze(-1)

        if valid_mask is None:
            alpha = torch.softmax(scores, dim=1)
        else:
            valid_mask = valid_mask.float()
            scores = scores.masked_fill(valid_mask == 0, -1e9)
            alpha = torch.softmax(scores, dim=1)
            alpha = alpha * valid_mask
            alpha = alpha / (alpha.sum(dim=1, keepdim=True) + 1e-8)

        pooled = torch.sum(alpha.unsqueeze(-1) * tokens, dim=1)
        return pooled, alpha


class ADMETEnhancedEncoder(nn.Module):
    def __init__(self, input_dim, output_dim, token_dim=128, num_heads=4, num_layers=1, dropout=0.2):
        super(ADMETEnhancedEncoder, self).__init__()

        self.input_norm = nn.LayerNorm(input_dim)
        self.tokenizer = FeatureTokenizer(input_dim, token_dim)

        self.blocks = nn.ModuleList([
            LightTransformerBlock(token_dim, num_heads=num_heads, dropout=dropout)
            for _ in range(num_layers)
        ])

        self.pool = ContextAwareAttentionPool(token_dim)
        self.token_proj = nn.Linear(token_dim, output_dim)

        self.global_mlp = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(128, output_dim)
        )

        self.gate = nn.Sequential(
            nn.Linear(output_dim * 2, output_dim),
            nn.Sigmoid()
        )

        self.out_norm = nn.LayerNorm(output_dim)

    def forward(self, x):
        available = (torch.sum(torch.abs(x), dim=1, keepdim=True) > 1e-8).float()
        x_norm = self.input_norm(x)

        tokens = self.tokenizer(x_norm)

        for block in self.blocks:
            tokens = block(tokens)

        token_feat, feature_alpha = self.pool(tokens)
        token_feat = self.token_proj(token_feat)

        global_feat = self.global_mlp(x_norm)

        gate = self.gate(torch.cat([token_feat, global_feat], dim=1))
        out = self.out_norm(gate * token_feat + (1.0 - gate) * global_feat)

        out = out * available
        feature_alpha = feature_alpha * available
        out = torch.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)

        info = {
            "admet_feature_alpha": feature_alpha
        }
        return out, info


class SparseTargetSetEncoder(nn.Module):
    def __init__(self, input_dim, output_dim, concept_dim=128, topk=12, num_heads=4, num_layers=1, dropout=0.2):
        super(SparseTargetSetEncoder, self).__init__()

        self.input_dim = input_dim
        self.output_dim = output_dim
        self.topk = topk

        self.input_norm = nn.LayerNorm(input_dim)

        self.concept_embedding = nn.Embedding(input_dim, concept_dim)
        nn.init.xavier_uniform_(self.concept_embedding.weight)

        self.blocks = nn.ModuleList([
            LightTransformerBlock(concept_dim, num_heads=num_heads, dropout=dropout)
            for _ in range(num_layers)
        ])

        self.pool = ContextAwareAttentionPool(concept_dim, context_dim=output_dim)
        self.set_proj = nn.Linear(concept_dim, output_dim)

        self.sparse_global_mlp = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(256, output_dim)
        )

        self.gate = nn.Sequential(
            nn.Linear(output_dim * 2 + 1, output_dim),
            nn.Sigmoid()
        )

        self.out_norm = nn.LayerNorm(output_dim)

    def _batched_topk_nonzero(self, x):
        batch_size, dim = x.size()
        real_k = min(self.topk, dim)

        values, indices = torch.topk(torch.abs(x), k=real_k, dim=1)
        valid_mask = values > 1e-8

        if real_k < self.topk:
            pad_k = self.topk - real_k
            pad_idx = torch.zeros(batch_size, pad_k, dtype=indices.dtype, device=indices.device)
            pad_val = torch.zeros(batch_size, pad_k, dtype=values.dtype, device=values.device)
            pad_mask = torch.zeros(batch_size, pad_k, dtype=torch.bool, device=values.device)

            indices = torch.cat([indices, pad_idx], dim=1)
            values = torch.cat([values, pad_val], dim=1)
            valid_mask = torch.cat([valid_mask, pad_mask], dim=1)

        return indices, values, valid_mask

    def forward(self, x, admet_context=None):
        available = (torch.sum(torch.abs(x), dim=1, keepdim=True) > 1e-8).float()
        x_norm = self.input_norm(x)

        topk_idx, topk_val, valid_mask = self._batched_topk_nonzero(x)
        norm_topk_val = topk_val / (torch.sum(topk_val, dim=1, keepdim=True) + 1e-8)

        token_feat = self.concept_embedding(topk_idx)
        token_feat = token_feat * norm_topk_val.unsqueeze(-1)
        token_feat = token_feat * valid_mask.unsqueeze(-1).float()

        safe_valid_mask = valid_mask.clone()
        all_invalid = (safe_valid_mask.sum(dim=1) == 0)
        if all_invalid.any():
            safe_valid_mask[all_invalid, 0] = True
            token_feat[all_invalid, 0, :] = 0.0

        key_padding_mask = ~safe_valid_mask

        for block in self.blocks:
            token_feat = block(token_feat, key_padding_mask=key_padding_mask)

        set_feat, token_alpha = self.pool(
            token_feat,
            valid_mask=valid_mask,
            context=admet_context
        )
        set_feat = self.set_proj(set_feat)

        sparse_global = self.sparse_global_mlp(x_norm)

        density = valid_mask.float().sum(dim=1, keepdim=True) / float(self.topk)
        gate = self.gate(torch.cat([set_feat, sparse_global, density], dim=1))
        out = self.out_norm(gate * set_feat + (1.0 - gate) * sparse_global)

        out = out * available
        token_alpha = token_alpha * valid_mask.float()
        weighted_importance = token_alpha * norm_topk_val

        out = torch.nan_to_num(out, nan=0.0, posinf=0.0, neginf=0.0)

        info = {
            "target_topk_indices": topk_idx,
            "target_topk_alpha": token_alpha,
            "target_topk_weighted_importance": weighted_importance,
            "target_valid_mask": valid_mask.float(),
            "target_density": density
        }
        return out, info


# =========================
# 新的 2层结构融合
# Chemical: SMILES + Graph
# Mechanism: ADMET + Target
# 然后 Chemical vs Mechanism
# =========================

class ModalityGate(nn.Module):
    def __init__(self, feature_dim, hidden_dim=64):
        super(ModalityGate, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(feature_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, x):
        return self.net(x)


class HierarchicalTwoBranchFusion(nn.Module):
    def __init__(self, feature_dim, gate_hidden_dim=64, temperature=1.5):
        super(HierarchicalTwoBranchFusion, self).__init__()
        self.temperature = temperature

        self.norm_smiles = nn.LayerNorm(feature_dim)
        self.norm_graph = nn.LayerNorm(feature_dim)
        self.norm_admet = nn.LayerNorm(feature_dim)
        self.norm_target = nn.LayerNorm(feature_dim)

        # 化学层内部
        self.smiles_gate = ModalityGate(feature_dim, gate_hidden_dim)
        self.graph_gate = ModalityGate(feature_dim, gate_hidden_dim)

        # 机制层内部
        self.admet_gate = ModalityGate(feature_dim, gate_hidden_dim)
        self.target_gate = ModalityGate(feature_dim, gate_hidden_dim)

        # 层间
        self.chem_gate = ModalityGate(feature_dim, gate_hidden_dim)
        self.mech_gate = ModalityGate(feature_dim, gate_hidden_dim)

        nn.init.constant_(self.smiles_gate.net[-1].bias, 0.1)
        nn.init.constant_(self.graph_gate.net[-1].bias, 0.1)
        nn.init.constant_(self.admet_gate.net[-1].bias, 0.0)
        nn.init.constant_(self.target_gate.net[-1].bias, 0.1)
        nn.init.constant_(self.chem_gate.net[-1].bias, 0.0)
        nn.init.constant_(self.mech_gate.net[-1].bias, 0.1)

    @staticmethod
    def build_mask(raw_x, eps=1e-8):
        return (torch.sum(torch.abs(raw_x), dim=1, keepdim=True) > eps).float()

    def _safe_softmax(self, scores, masks=None):
        if masks is not None:
            scores = scores.masked_fill(masks == 0, -1e9)
        alpha = torch.softmax(scores / self.temperature, dim=1)
        alpha = torch.nan_to_num(alpha, nan=0.0, posinf=0.0, neginf=0.0)
        if masks is not None:
            alpha = alpha * masks.float()
            alpha = alpha / (alpha.sum(dim=1, keepdim=True) + 1e-8)
        return alpha

    def forward(self, f_smiles, f_graph, f_admet, f_target, raw_admet=None, raw_target=None):
        f_smiles = self.norm_smiles(f_smiles)
        f_graph = self.norm_graph(f_graph)
        f_admet = self.norm_admet(f_admet)
        f_target = self.norm_target(f_target)

        batch_size = f_smiles.size(0)
        device = f_smiles.device

        # ===== 化学层内部 =====
        chem_scores = torch.cat([
            self.smiles_gate(f_smiles),
            self.graph_gate(f_graph)
        ], dim=1)
        chem_alpha = self._safe_softmax(chem_scores)
        chem_feature = (
            chem_alpha[:, 0:1] * f_smiles +
            chem_alpha[:, 1:2] * f_graph
        )

        # ===== 机制层内部 =====
        mech_scores = torch.cat([
            self.admet_gate(f_admet),
            self.target_gate(f_target)
        ], dim=1)

        mask_admet = self.build_mask(raw_admet) if raw_admet is not None else torch.ones((batch_size, 1), device=device)
        mask_target = self.build_mask(raw_target) if raw_target is not None else torch.ones((batch_size, 1), device=device)
        mech_masks = torch.cat([mask_admet, mask_target], dim=1)

        mech_alpha = self._safe_softmax(mech_scores, mech_masks)
        mech_feature = (
            mech_alpha[:, 0:1] * f_admet +
            mech_alpha[:, 1:2] * f_target
        )

        # ===== 层间 =====
        layer_scores = torch.cat([
            self.chem_gate(chem_feature),
            self.mech_gate(mech_feature)
        ], dim=1)

        mech_available = ((mask_admet + mask_target) > 0).float()
        layer_masks = torch.cat([
            torch.ones((batch_size, 1), device=device),
            mech_available
        ], dim=1)

        layer_alpha = self._safe_softmax(layer_scores, layer_masks)
        fused_feature = (
            layer_alpha[:, 0:1] * chem_feature +
            layer_alpha[:, 1:2] * mech_feature
        )

        fused_feature = torch.nan_to_num(fused_feature, nan=0.0, posinf=0.0, neginf=0.0)

        # 展平成 4 分支总权重，方便你继续打印
        final_alpha = torch.cat([
            layer_alpha[:, 0:1] * chem_alpha[:, 0:1],  # SMILES
            layer_alpha[:, 0:1] * chem_alpha[:, 1:2],  # Graph
            layer_alpha[:, 1:2] * mech_alpha[:, 0:1],  # ADMET
            layer_alpha[:, 1:2] * mech_alpha[:, 1:2],  # Target
        ], dim=1)
        final_alpha = torch.nan_to_num(final_alpha, nan=0.25, posinf=0.25, neginf=0.25)

        chem_entropy = -torch.sum(chem_alpha * torch.log(chem_alpha + 1e-8), dim=1).mean()
        mech_entropy = -torch.sum(mech_alpha * torch.log(mech_alpha + 1e-8), dim=1).mean()
        layer_entropy = -torch.sum(layer_alpha * torch.log(layer_alpha + 1e-8), dim=1).mean()
        entropy_reg = (chem_entropy + mech_entropy + layer_entropy) / 3.0

        fusion_info = {
            "modality_alpha": final_alpha,
            "chem_alpha": chem_alpha,
            "mech_alpha": mech_alpha,
            "layer_alpha": layer_alpha
        }

        return fused_feature, fusion_info, entropy_reg


class InteractionPredictor(nn.Module):
    def __init__(self, hidden_dim):
        super(InteractionPredictor, self).__init__()

        self.predictor = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )

    def forward(self, mirna_features, drug_features):
        combined = torch.cat([mirna_features, drug_features], dim=1)
        score = self.predictor(combined)
        return score.squeeze(-1)


class DrugMiRNAInteractionModel(nn.Module):
    def __init__(self, args):
        super(DrugMiRNAInteractionModel, self).__init__()

        # miRNA side
        self.mirna_cnn = CNNFeatureExtractor(output_dim=args.mirna_feature_dim)
        self.mirna_rnafm = RNAFMFeatureExtractor(output_dim=args.mirna_feature_dim)
        self.mirna_fusion = FeatureFusion(feature_dim=args.mirna_feature_dim)

        # drug chemical side
        self.drug_gcn = GCNFeatureExtractor(
            input_dim=args.drug_input_dim,
            hidden_dim=args.drug_hidden_dim,
            output_dim=args.drug_feature_dim,
        )
        self.drug_chembert = ChemBERTaFeatureExtractor(output_dim=args.drug_feature_dim)

        # mechanism side
        self.drug_admet_encoder = ADMETEnhancedEncoder(
            input_dim=args.drug_admet_dim,
            output_dim=args.drug_feature_dim,
            token_dim=args.admet_token_dim,
            num_heads=args.admet_num_heads,
            num_layers=args.admet_num_layers,
            dropout=args.dropout
        )

        self.drug_target_encoder = SparseTargetSetEncoder(
            input_dim=args.drug_target_raw_dim,
            output_dim=args.drug_feature_dim,
            concept_dim=args.target_concept_dim,
            topk=args.target_topk,
            num_heads=args.target_num_heads,
            num_layers=args.target_num_layers,
            dropout=args.dropout
        )

        self.drug_fusion = HierarchicalTwoBranchFusion(
            feature_dim=args.drug_feature_dim,
            gate_hidden_dim=64,
            temperature=args.fusion_temperature
        )

        self.interaction_predictor = InteractionPredictor(
            hidden_dim=args.mirna_feature_dim + args.drug_feature_dim
        )

        self.latest_fusion_weights = None
        self.latest_entropy_reg = None
        self.latest_mechanism_info = None

    def forward(self, drug_graphs, drug_smiles, drug_desc, drug_fp,
                drug_admet, drug_target_pathway, mirna_encoded, mirna_seqs):
        device = next(self.parameters()).device

        if isinstance(drug_graphs, list):
            drug_batch = Batch.from_data_list(drug_graphs)
        else:
            drug_batch = drug_graphs

        drug_batch = drug_batch.to(device)
        mirna_encoded = mirna_encoded.to(device)
        drug_admet = drug_admet.to(device)
        drug_target_pathway = drug_target_pathway.to(device)

        # miRNA side
        m1, cnn_tokens, cnn_mask = self.mirna_cnn(
            mirna_encoded, return_tokens=True
        )
        m2, fm_tokens, fm_mask = self.mirna_rnafm(
            mirna_seqs, return_tokens=True
        )
        mirna_features = self.mirna_fusion(
            m1, m2, cnn_tokens, fm_tokens, cnn_mask, fm_mask
        )

        # chemical
        d_graph = self.drug_gcn(drug_batch.x, drug_batch.edge_index, drug_batch.batch)
        d_smiles = self.drug_chembert(drug_smiles)

        # mechanism
        d_admet, admet_info = self.drug_admet_encoder(drug_admet)
        d_target, target_info = self.drug_target_encoder(
            drug_target_pathway,
            admet_context=d_admet
        )

        # hierarchical fusion
        drug_features, fusion_info, entropy_reg = self.drug_fusion(
            f_smiles=d_smiles,
            f_graph=d_graph,
            f_admet=d_admet,
            f_target=d_target,
            raw_admet=drug_admet,
            raw_target=drug_target_pathway
        )

        fusion_info.update(admet_info)
        fusion_info.update(target_info)

        self.latest_fusion_weights = fusion_info["modality_alpha"]
        self.latest_entropy_reg = entropy_reg
        self.latest_mechanism_info = fusion_info

        interaction_score = self.interaction_predictor(mirna_features, drug_features)
        interaction_score = torch.nan_to_num(interaction_score, nan=0.5, posinf=1.0, neginf=0.0)
        interaction_score = torch.clamp(interaction_score, min=1e-6, max=1 - 1e-6)

        return interaction_score, fusion_info, entropy_reg
